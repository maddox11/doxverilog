/**
 * Java Program to Implement Tarjan Algorithm
 **/
package xml.graph;

import java.util.*;

/** class Tarjan **/
public class Tarjan {
    /** number of vertices **/
    private int V;
    /** preorder number counter **/
    private int preCount;
    /** low number of v **/
    private HashMap<Integer,Integer> low;
    /** to check if v is visited **/
    private HashMap<Integer,Boolean> visited;
    /** to store given graph **/
    private static Map<Integer, LinkedHashSet<Integer>> graph;
   // private List <Integer>[] graph;
    /** to store all scc **/
    private List <List <Integer>> sccComp;
    private Stack <Integer> stack;

    /** function to get all strongly connected components **/
    public List <List <Integer>> getSCComponents( Map<Integer, LinkedHashSet<Integer>> graph) {
        V = graph.keySet().size();
        this.graph = graph;
        low = new HashMap<>(V);
        visited = new HashMap<>(V);
        stack = new Stack <>();
        sccComp = new ArrayList <>();
        Set<Integer> il=graph.keySet();

        for(int i:il){
            visited.put(i,false);
            low.put(i,0);
        }
        il=graph.keySet();
        for (int v : il)
            if (!visited.get(v))
                dfs(v);

        return sccComp;
    }

    public Tarjan(){}

    /** function dfs **/
    public void dfs(int v) {
        low.put(v,preCount++);
        visited.put(v,true);
        stack.push(v);
        int min = low.get(v);
        for (int w : graph.get(v)) {
            if (!visited.get(w))
                dfs(w);
            if (low.get(w) < min)
                min = low.get(w);
        }
        if (min < low.get(v)) {
            low.put(v, min);
            return;
        }
        List <Integer> component = new ArrayList <Integer>();
        int w;
        do {
            w = stack.pop();
            component.add(w);
            low.put(w, V);
        } while (w != v);
        sccComp.add(component);
    }
    /** main **/
    /**
     public static void main(String[] args)
     {
     Scanner scan = new Scanner(System.in);
     System.out.println("Tarjan algorithm Test\n");
     System.out.println("Enter number of Vertices");
     int V = scan.nextInt();

     List<Integer>[] g = new List[V];
     for (int i = 0; i < V; i++)
     g[i] = new ArrayList<Integer>();
     System.out.println("\nEnter number of edges");
     int E = scan.nextInt();
     System.out.println("Enter "+ E +" x, y coordinates");
     for (int i = 0; i < E; i++)
     {
     int x = scan.nextInt();
     int y = scan.nextInt();
     g[x].add(y);
     }

     Tarjan t = new Tarjan();
     System.out.println("\nSCC : ");
     List<List<Integer>> scComponents = t.getSCComponents(g);
     System.out.println(scComponents);
     }
     */
}
