package xml.graph;

import java.util.*;
import java.util.List;

import xml.*;
import xml.geom.Edge;


public class DFS {

    private boolean[] visited;
    private int[] color;
    private int[] detect;
    private int[] finish;

    private int time = 0;

    private Map<Integer, LinkedHashSet<Integer>> gr = null;
    private List<Edge> backEdge = new ArrayList<>();
    private List<Edge> eEdge = new ArrayList<>();
    private List<String> finList = new ArrayList<>();
    private List<String> detectList = new ArrayList<>();


    public DFS() {
    }


    public List<Edge> dsf(Graph graph, int node) {

        gr = graph.getEdges();
        backEdge.clear();
        time = 0;
        int n = gr.size() + 2;
        visited = new boolean[n];
        color = new int[n];
        detect = new int[n];
        finish = new int[n];

        dsfVisit(node);
        for (Edge eg : eEdge) {
            boolean b1 = detect[eg.v] <= detect[eg.u];
            boolean b2 = detect[eg.u] < finish[eg.u];
            boolean b3 = finish[eg.u] <= finish[eg.v];

            if (b1 && b2 && b3) {

                  System.out.println("backEdge:" +
                  Device.getCompName(eg.u) + "-###->" +
                  Device.getCompName(eg.v));

                eg.edgeType = Edge.BACKEDGE;
                backEdge.add(eg);

            }
        }
        return backEdge;
    }// dfs

    private void dsfVisit(int u) {
        time++;
        detect[u] = time;
        color[u] = 1;

        for (int v : gr.get(u)) {
            if (!visited[v]) {
                visited[v] = true;
                dsfVisit(v);
            } else {
                Edge ee = new Edge(u, v);
                eEdge.add(ee);
            }
        }

        color[u] = 2;
        time++;
        finish[u] = time;
    }// dfsVisit





}// class
