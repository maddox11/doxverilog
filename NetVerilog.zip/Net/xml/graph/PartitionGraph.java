package xml.graph;

import xml.Device;
import xml.Entity;
import xml.Href;
import xml.geom.Edge;

import java.util.*;

public class PartitionGraph {

    private int nodes;
    private Map<Integer, LinkedHashSet<Integer>> gr = null;
    private Map<Integer, String> tree = new java.util.TreeMap<>();
    private List<String> detectList = new ArrayList<>();
    private List<String> finishList = new ArrayList<>();
    private HashMap<Integer, Boolean> vi = null;
    private Stack<List<Integer>> partList = new Stack<List<Integer>>();
    private HashMap<Integer, List<Edge>> edgeList;
    private Graph gT = null;
    private static int idd;

    private Graph gInv = null;

    public HashMap<Integer, List<Edge>> getEdgeList() {
        return edgeList;
    }

    public Graph getgT() {
        return gT;
    }


    private static ArrayList<PartGraph> partGraphList = new ArrayList<>();

    public static PartGraph getPartitionGraph(int i) {
        return partGraphList.get(i);
    }

    public PartGraph getPartGraph(int i) {
        return partGraphList.get(i);
    }

    public List<PartGraph> getPartGraphList() {
        return partGraphList;
    }

    //  g is the inverse graph
    public PartitionGraph(Graph g, int superOutput, int size) {
        gT = g.inverseGraph();
        gr = g.getEdges();
        gInv = g;
        nodes = gr.size();
        edgeList = new HashMap<>(nodes);
        dsf(gInv, superOutput);
        divideGraph();
        assignIOPins();

        for (List<Integer> li : partList) {
            PartGraph pg = new PartGraph(this, li, gT,idd++);
            partGraphList.add(pg);
        }
    }

    public void dsf(final Graph g, int node) {
        int n = g.getEdges().size() + 2;
        vi = new HashMap<>(n);
        tree.put(node, Device.getEntity(node).getCompName());
        java.util.Set<Integer> is = g.getEdges().keySet();
        for (int i : is)
            vi.put(i, false);
        dsfVisit(node);

        System.out.println(node);
    }// dfs

    private void dsfVisit(int u) {
        //    System.out.println("visit node:" + Device.getEntity(u).getCompName());
        detectList.add(Device.getEntity(u).getCompName());
        for (int v : gr.get(u)) {
            Entity v1 = Device.getEntity(v);
            if (!vi.get(v)) {
                tree.put(v, v1.getCompName());
                //      System.out.println("visit successor:" + v1.getCompName() + " from node " + Device.getEntity(u).getCompName());
                vi.put(v, true);
                dsfVisit(v);
            }
        }

        String name = Device.getEntity(u).getCompName();
        if (!(name == "SI" || name == "SO" || name == Device.getTopModuleName()))
            finishList.add(Device.getEntity(u).getCompName());
    }// dfsVisit


    public void divideGraph() {

        int divider = (int) 500 / 3;
        int counter = 0;
        List<Integer> vList = new ArrayList<>(divider);
        for (String s : finishList) {
            if (counter < divider) {
                vList.add(Device.getEntity(s).getIdd());
            } else {
                counter = 0;
                partList.push(vList);
                vList = new ArrayList<>(divider);

            }
            counter++;
        }

        if (!vList.isEmpty())
            partList.push(vList);

    }

    public void printEntEdges(String ent, boolean inout) {
        int idd = Device.getEntity(ent).getIdd();
        System.out.println(idd);
        System.out.println("print incoming edges for entity: " + ent);
        List<String> strl = gInv.getEdgeNames(ent);

        if (!inout) return;
        strl = gT.getEdgeNames(ent);

        System.out.println("print outcoming edges for entity: " + ent);
        for (String s : strl)
            System.out.println(ent + " --> " + s);

        System.out.println("------------------");

    }


    public void assignIOPins() {
        Set<Integer> iset = tree.keySet();
        for (int u : iset) {
            String ent = Device.getEntity(u).getCompName();
            edgeList.put(u, new ArrayList<>());
            List<Edge> li = edgeList.get(u);
            System.out.println("adding outcoming edges for entity: " + ent);

            for (String s : gT.getEdgeNames(ent))
                li.add(new Edge(u, Device.getEntityIDD(s)));

            for (String s : gInv.getEdgeNames(ent))
                li.add(new Edge(Device.getEntityIDD(s), u));
        }

    }//assignIOPins


}//class

