package xml.graph;

import java.util.*;

import xml.Device;

public class BFS {

    private int[] dist;

    private Deque <Integer> deq;


    public ArrayList <ArrayList <Integer>> bfs(Graph graph, String s) {
        int i;
        i = Device.getEntityIDD(s);
        return bfs(graph, i);
    }

    public ArrayList <ArrayList <Integer>> bfs(PartGraph pg, int i) {
        return bfs(pg.getPartGraph(), i);
    }


    public BFS() {
    }


    public ArrayList <ArrayList <Integer>> bfs(Graph gInv, int source) {

        ArrayList <ArrayList <Integer>> res = new ArrayList <ArrayList <Integer>>();
        ArrayList <Integer> tmp;// new ArrayList<>();
        HashMap<Integer,Boolean> visited=new HashMap<>(gInv.getEdges().size());
        HashMap<Integer,Integer> dist=new HashMap<>(gInv.getEdges().size());

        deq = new ArrayDeque <>();
        Set<Integer> set=gInv.getEdges().keySet();
        for (int j:set) {
            visited.put(j,false);
            dist.put(j,Integer.MAX_VALUE);
        }

        deq.add(source);
        dist.put(source,0);
        while (!deq.isEmpty()) {
            int u = deq.removeFirst();

            LinkedHashSet <Integer> lh = gInv.getEdges().get(u);
              if (lh == null)
                continue;
            tmp = new ArrayList <>();
            for (int v : lh) {
                if (!visited.get(v)) {
                    visited.put(v,true);
                    deq.add(v);
                    dist.put(v,dist.get(u) + 1);
                    tmp.add(v);
                 }
            }
            if (tmp.size() > 0) {
                  res.add(tmp);
            }
        }//while
        return res;
    }//dfs


    public static void debug(Map <Integer, LinkedHashSet <Integer>> arr, int source) {

        System.out.println("(0) " + Device.getEntity(source).getCompName());
        Set<Integer> iset=arr.keySet();
        int index = 1;
        for (Integer io : iset) {
            String nn = Device.getEntity(io).getCompName();
            System.out.print("(" + index + " : "+ nn+") ");
            int i1 = 0;
            for (int ii : arr.get(io)) {
                String name = Device.getEntity(ii).getCompName();
                System.out.print(name + " ");
             }
            index++;
            System.out.println("{" + index + "}");
        }
    }
}
