package xml.graph;

import xml.Device;
import xml.Entity;
import xml.geom.Edge;
import xml.geom.Port;

import java.util.*;

public class PartGraph {

    private static final int SO_ID = Integer.MAX_VALUE;
    private static final int SI_ID = Integer.MAX_VALUE - 1;

    private PartitionGraph partitionGraph;
    private Hashtable<String, Entity> vertSet = new Hashtable<>();
    private Hashtable<Integer, Entity> vertics;
    private Graph partGraph = null;
    private HashSet<Integer> nodeSet = new HashSet<>();
    private HashSet<Edge> pin;
    private HashSet<Edge> pout;
    private int vc = 0;
    private  int idd;

    public PartGraph(PartitionGraph partitionGraph, List<Integer> li, Graph g,int id) {
        this.partitionGraph = partitionGraph;
        idd=id;
        nodeSet.addAll(li);
        vc = g.getEdges().size() + 100;
        vertics = new Hashtable(li.size() + 10);
        addNodes(li);
        System.out.println("--------------------NodeSet-----------------------------");
        printNodeSet(nodeSet);
        Graph g1 = createPartGraph(li);
        pin = getPortEdges(true);
        System.out.println("--------------------inports-----------------------------");
        Edge.printEdge(pin);
        System.out.println("--------------------get outport-----------------------------");
        pout = getPortEdges(false);
        System.out.println("--------------------print outports -----------------------------");
        Edge.printEdge(pout);
        buildOutPins(pout, g1);
        buildInputPins(pin, g1);
        removeAllOutPins();
        partGraph = g1.inverseGraph();
    }

    public int getSoId() {
        return SO_ID;
    }

    public int getGraphID() { return idd;}

    private void addNodes(List<Integer> li) {
        for (int i : li) {
            Entity e = Device.getEntity(i).deepClone();
            vertics.put(i, e);
        }
    }

    public void printInputEdges() {
        Edge.printEdge(pin);
    }

    public void printOutputEdges() {
        Edge.printEdge(pout);
    }

    public HashSet<Edge> getPortEdges(boolean dir) {
        HashSet<Edge> po = new HashSet<>();
        for (int ii : nodeSet) {
            List<Edge> el = partitionGraph.getEdgeList().get(ii);
             for (Edge ee : el) {
                 if (nodeSet.contains(ee.u) && nodeSet.contains(ee.v))
                    continue;
                if (dir) {
                    if (ee.v == ii)
                        po.add(ee);
                } else {
                    if (ee.u == ii && !isInputPin(ee.u))
                        po.add(ee);
                }
            }
        }// for

        if (dir) {
            List<Edge> el = Device.getBackEdges();
            for (Edge ee : el) {
                if (nodeSet.contains(ee.u) && !nodeSet.contains(ee.v)) {
                    Edge e = new Edge(ee.v, ee.u);
                    po.add(e);
                }
            }
        }
        return po;
    }

    public void removeAllOutPins() {
        HashSet<Integer> hs = new HashSet<>(vertics.keySet());
        Collection<Entity> col = vertics.values();
        for (Entity el : col)
            vertSet.put(el.getCompName(), el);
        Enumeration<Entity> en = vertics.elements();
        while (en.hasMoreElements()) {
            Entity ent = en.nextElement();
            //  if(!ent.isInputPin())continue;
            if (ent.getCompName().equalsIgnoreCase("U190"))
                System.out.println("remvove u442");

            for (Port p : ent.getAllOutPorts()) {
                boolean loop = true;
                while (loop) {
                    loop = p.removeAllNotLinkedOutPorts(hs, vertSet);
                }
            }// for
            //  System.out.println("----------------------------------------");
        }
    }

    public void buildInputPins(HashSet<Edge> pin, Graph g) {
        Entity si = getNode(SI_ID);
        si.addOutPort("SI");
        HashMap<String, Integer> hs = new HashMap<>();
        for (Edge ee : pin) {
            //  ee.printEdge();
            if (!isSuperInput(ee.u))
                continue;
            Entity li = getNode(ee.v);
            if (li.getCompName().equalsIgnoreCase("PORT7"))
                System.out.println();
            g.removeEdge(ee.u, ee.v);
            g.removeNode(ee.u);
            g.addEdge(SI_ID, ee.v);
        }

        for (Edge ee : pin) {
            //   ee.printEdge();
            if (isSuperInput(ee.u))
                continue;

            boolean u = nodeSet.contains(ee.u);
            boolean v = nodeSet.contains(ee.v);

            if (!u && v) {
                Entity from = Device.getEntity(ee.u);
                Entity to = getNode(ee.v);
                Port[] pp = from.hasOutputLinkTo(to);
                if (pp == null)
                    continue;
                vc++;
                String name = from.getCompName() + "_0";
                if (!hs.containsKey(name)) {
                    Entity ent = createInputEntity(name, pp[0].getPortName(), vc);
                    Port p = ent.getOutputPort(pp[0].getPortName());
                    p.addPort(pp[1]);
                    g.addNode(vc);
                    g.addEdge(vc, to.getIdd());
                    g.addEdge(SI_ID, vc);
                    hs.put(name, vc);
                } else {
                    Entity e1 = getNode(hs.get(name));
                    Port p = e1.getOutputPort(pp[0].getPortName());
                    p.addPort(pp[1]);
                    g.addEdge(e1.getIdd(), to.getIdd());
                }
            }
        }
    }


    public void buildOutPins(HashSet<Edge> pout, Graph g) {
        System.out.println("<------------ creating outports -------->");
        HashMap<String, Entity> hs = new HashMap<>();
        for (Edge ee : pout) {
             deleteLink(hs, ee, g);
        }
        System.out.println("<------------end creating outports -------->");
        System.out.println(hs.toString());
    }

    public void deleteLink(HashMap<String, Entity> hs, Edge ee, Graph g) {
        Entity from = vertics.get(ee.u);
        Entity to = Device.getEntity(ee.v);

        if (from.getCompName().equalsIgnoreCase("rxcrirq"))
            System.out.println(to.getCompName());

        if (to.getCompName().equalsIgnoreCase("rxcirq"))
            System.out.println(to.getCompName());


        if (isSuperOut(ee.v)) {
            g.addEdge(ee.u, SO_ID);
        }

        Vector<Port> vp = from.getAllOutPorts();
        for (Port po : vp) {
            while (po.removeLinkedPort(to.getCompName())) {
            }
            if (from.isInputPin())
                continue;
            String port = "DATA_" + po.getPortName();
            String name = from.getCompName() + "_" + po.getPortName();
            if (!hs.containsKey(name)) {
                vc++;
                System.out.println("add outport:" + name + " " + port + " " + ee.v);
                Entity et = createOutEntity(name, port, vc, false);
                po.addPort(et.getInputPort(port));
                hs.put(name, et);
                g.addNode(vc);
                g.addEdge(ee.u, vc);
                g.addEdge(vc, SO_ID);
            } else {
                //  System.out.println(name+" "+port);
            }
        }
    }


    // graph with forward edges

    public Graph createPartGraph(List<Integer> li) {

        Graph g = new Graph();

        vertics.put(SO_ID, new Entity("SO", SO_ID));
        vertics.put(SI_ID, new Entity("SI", SI_ID));

        g.addNode(SO_ID);
        g.addNode(SI_ID);
        for (Integer u : li) {
            g.addNode(u);
            HashSet<Integer> hs = partitionGraph.getgT().getEdges().get(u);
            if (hs == null) continue;
            for (Integer v : hs) {
                Edge ee = new Edge(u, v);
                if (!nodeSet.contains(v) || isSuperIO(v)) {
                    //  System.out.println("not containing Edge");
                    //  ee.printEdge();
                    //  System.out.println("---------------------");
                    continue;
                }
                //    System.out.println("*****");
                //   ee.printEdge();
                g.addEdge(u, v);
            }
        }
        //-------------------------------------------------------
        //   List<String> lih = g.getEdgeNames("U438");
        return g;
    }


    private HashSet<Integer> getInOutPins(boolean dir) {
        HashSet<Integer> hs = new HashSet<>();

        for (Edge ee : pout)
            // input dir=true;
            if (dir)
                hs.add(ee.u);
            else
                hs.add(ee.v);
        return hs;
    }

    private Entity createInputEntity(String name, String port, int idd) {
        Entity ee = new Entity(name, idd);
        ee.name = "input";
        ee.lpm_type = "input";
        vertics.put(idd, ee);
        ee.addOutPort(port);
        return ee;
    }

    private Entity createOutEntity(String name, String port, int idd, boolean dir) {
        Entity ee = new Entity(name, idd);
        ee.name = "output";
        ee.lpm_type = "output";
        vertics.put(idd, ee);
        ee.addInport(port);
        return ee;
    }

    public Entity getNode(int idd) {
        return vertics.get(idd);
    }

    public Hashtable<Integer, Entity> getVertics() {
        return vertics;
    }

    public Hashtable<String, Entity> getNodes() {
        return vertSet;
    }

    public Graph getPartGraph() {
        return partGraph;
    }


    private void checkNode(String node, Graph g1) {
        System.out.println("------------------------");
        getOutEdges(Device.getEntityIDD(node), g1);
        System.out.println("------------------------");
        getOutEdges(Device.getEntityIDD(node), partGraph);
        // debug(partGraph.getEdges(),SO_ID);
    }

    private List<Integer> getOutEdges(int i, Graph g) {
        //  int i = Device.getEntityIDD(node);
        List<Integer> vec = new ArrayList<>();
        Set<Integer> setI = g.getEdges(i);
        setI.forEach(s->vec.add(s));
        return vec;
     /**
        Iterator<Integer> iter = setI.iterator();
        {
            while (iter.hasNext()) {
                int ii = iter.next().intValue();
                String s2 = vertics.get(ii).getCompName();
//                    System.out.println(vertics.get(i).getCompName() + "-- edge -->" + s2 + " " + ii);
                assert (nodeSet.contains(ii));
                vec.add(ii);
            }
        }
        return vec;
        */
    }

    private void printNodeSet(Set<Integer> set) {
        System.out.println("----------- vertics set------------------------");
        for (int i : set) {
            String s2 = Device.getEntity(i).getCompName();
            System.out.println(" vertex:" + vertics.get(i).getCompName() + " idd:" + vertics.get(i).getIdd());
        }
        System.out.println("----------- vertics set------------------------");
    }


    private boolean isInputPin(int idd) {
        return Device.getEntity(idd).isInputPin();
    }

    private boolean isOutputPin(int idd) {
        return Device.getEntity(idd).isOutputPin();
    }

    private boolean isSuperOut(int idd) {
        if (Device.getEntity(idd).getCompName() == "SO")
            return true;
        return false;
    }

    private boolean isSuperInput(int idd) {
        if (Device.getEntity(idd).getCompName() == "SI")
            return true;
        return false;
    }

    private boolean isSuperIO(int idd) {
        if (Device.getEntity(idd).getCompName() == "SI" || Device.getEntity(idd).getCompName() == "SO")
            return true;
        return false;
    }

    public void debug(Map<Integer, LinkedHashSet<Integer>> arr) {
        debug(arr, SO_ID);
    }

    public void debug(Map<Integer, LinkedHashSet<Integer>> arr, int source) {

        System.out.println("(0) " + vertics.get(source).getCompName());
        Set<Integer> iset = arr.keySet();
        int index = 1;
        for (Integer io : iset) {
            String nn = vertics.get(io).getCompName();
            System.out.print("(" + index + " : " + nn + ") ");
            int i1 = 0;
            for (int ii : arr.get(io)) {
                String name = vertics.get(ii).getCompName();
                System.out.print(name + " ");
            }
            index++;
            System.out.println("{" + index + "}");

        }

    }

    public void debug(List<List<Integer>> scc) {
        int index = 0;
        System.out.println("==================== SCC ================");
        for (List<Integer> li : scc) {
            if (li.size() == 1) continue;
            System.out.println();
            System.out.print("[" + index + "] ");
            for (Integer ii : li) {
                String s = vertics.get(ii).getCompName();
                System.out.print(s + " ");
            }
            System.out.println();
            index++;
        }
    }

    void debug(int round) {
        System.out.println("---[" + round + "]: Input ---------------");
        printInputEdges();
        System.out.println("---[" + round + "]: Output ---------------");
        printOutputEdges();
        System.out.println("---------------------------");
    }
}//class partgraph
