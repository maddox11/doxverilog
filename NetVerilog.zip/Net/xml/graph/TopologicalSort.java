package xml.graph;

import java.util.*;

import xml.Device;
import xml.Entity;

public class TopologicalSort {


	static void dfs(Map<Integer, LinkedHashSet<Integer>> graph, HashMap<Integer,Boolean> used,
			List<Integer> res, int u) {
		used.put(u,true);
		LinkedHashSet<Integer> lh = graph.get(u);
	
		if (lh == null)
			return;
		
		for (int v : lh)
			if (!used.get(v))
				dfs(graph, used, res, v);
		res.add(u);
	}



	public static List<Integer> topoSort(Graph graph) {
		int n = graph.getEdges().size() + 1;
	    HashMap<Integer,Boolean> used=new HashMap<>(n+1);
		 Set<Integer> hg=graph.getEdges().keySet();
		 for(int i:hg)
		 	used.put(i,false);

		List<Integer> res = new ArrayList<>();

		for (int i :hg) {
			if (!used.get(i)) {
				dfs(graph.getEdges(), used, res, i);
			}
		}

		Collections.reverse(res);
		System.err.println(res.size());
		return res;
	}

	public static void printTopoSort(List<Integer> li) {
		Iterator<Integer> iter = li.iterator();
		System.out.println("============ TopoSort ===================");
		int index=0;
		while (iter.hasNext()) {
			int ii = iter.next().intValue();
			Entity e = Device.getEntity(ii);
			String val = Device.getCompName(ii);
			System.out.println("("+index++ +") "+val + " ]--[ " + e.getIdd());
		}
		System.out.println("===============================");

	}
}
