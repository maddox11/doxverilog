package xml.graph;

import xml.Device;
import xml.Entity;
import xml.geom.Edge;


import java.util.*;
//------------------------------------------------------------------------

public class Graph {

    protected boolean bCycles = false;

    protected List<List<Integer>> sccGraph = null;

    private Map<Integer, LinkedHashSet<Integer>> edges = new TreeMap<>();

    private int numEdges = 0;

    public void addNode(int u) {
        if (!edges.containsKey(u)) {
            edges.put(u, new LinkedHashSet<>());
        }
    }

    public Graph(Graph g) {
        this.numEdges = g.numEdges;
        this.edges.putAll(g.edges);
        this.bCycles = g.bCycles;
    }

    public Graph() {
    }

    public void removeNode(int u) {
        if (!edges.containsKey(u)) {
            return;
        }

        for (int v : edges.get(u)) {
            edges.get(v).remove(u);
        }
        edges.remove(u);
    }

    public Map<Integer, LinkedHashSet<Integer>> getEdges() {

        return edges;
    }


    public List<String> getEdgeNames(String s) {
        return getEdgeNames(Device.getEntity(s).getIdd());
    }

    public List<String> getEdgeNames(int i) {

        ArrayList<String> sl = new ArrayList<>();
        LinkedHashSet<Integer> li = edges.get(i);

        for (int ii : li) {
            Entity ee = Device.getEntity(ii);
            sl.add(ee.getCompName());
        }

        return sl;
    }


    public LinkedHashSet<Integer> getEdges(int i) {

        return edges.get(i);
    }

    public void addEdge(int u, int v) {
        addNode(u);
        addNode(v);

        LinkedHashSet<Integer> ihash = edges.get(u);
        if (!ihash.contains(v))
            numEdges++;
        edges.get(u).add(v);
    }

    public Graph inverseGraph() {

        Graph g = new Graph();
        Set<Integer> setI = this.edges.keySet();
        Iterator<Integer> iter = setI.iterator();

        while (iter.hasNext()) {
            int ii = iter.next();
            LinkedHashSet<Integer> lii = edges.get(ii);
            for (int v : edges.get(ii)) {
                Entity xx = Device.getEntity(v);
                g.addEdge(v, ii);
            }
        }
        return g;
    }

    public Set<Edge> removeEdgeSCC(List<Edge> ee) {
        Set<Edge> eli = new LinkedHashSet<Edge>();
        for (Edge e : ee) {

            if (!(e.edgeType == Edge.BACKEDGE))
                continue;
            e.printEdge();
            removeEdge(e.u, e.v);
            eli.add(new Edge(e.u, e.v));
        }
        return eli;
    }

    public boolean removeAllEdges(int u) {
        if (!edges.containsKey(u)) {
            System.out.println("missing node:");
            System.exit(777);
            return false;
        }
        edges.get(u).clear();
        return true;
    }

    public boolean removeEdge(int u, int v) {

        if (!edges.containsKey(u))
            return false;
        boolean con = edges.get(u).remove(v);

        if (!con) {
            System.out.println("missing edge: " + u + "-->" + v);
            return false;
        }

        this.numEdges--;
        return true;

    }

    public List<Edge> getEdgeList() {
        ArrayList<Edge> al = new ArrayList<Edge>();

        Set<Integer> setI = edges.keySet();
        Iterator<Integer> iter = setI.iterator();

        while (iter.hasNext()) {
            int ii = iter.next();
            for (int v : edges.get(ii)) {
                al.add(new Edge(v, ii));
            }
        }
        return al;
    }// getEdgeList


    public Graph clone() {
        Graph g = new Graph();
        g.bCycles = this.bCycles;

        Set<Integer> setI = edges.keySet();
        Iterator<Integer> iter = setI.iterator();

        while (iter.hasNext()) {
            Integer ii = iter.next();
            for (int v : edges.get(ii)) {
                g.addEdge(ii.intValue(), v);
            }
        }

        return g;
    }


    public List<List<Integer>> getSCC() {
        return sccGraph;
    }

    public List<String> getOutEdges(String node) {
        int s1 = Device.getEntityIDD(node);
        List<String> vec = new ArrayList<String>();
        Set<Integer> setI = edges.get(s1);
        Iterator<Integer> iter = setI.iterator();
        {
            while (iter.hasNext()) {
                int ii = iter.next().intValue();
                String s2 = Device.getCompName(ii);
                //	System.out.println(node+"-- edge -->"+s2+" "+ii);
                vec.add(s2);
            }
        }
        return vec;
    }


    public void printNodes() {
        Set<Integer> setI = edges.keySet();
        Iterator<Integer> iter = setI.iterator();
        System.out.println("============ Nodes ===================");
        while (iter.hasNext()) {
            int ii = iter.next().intValue();
            Entity e = Device.getEntity(ii);
            String val = Device.getCompName(ii);
            System.out.println(val + " " + e.getIdd());
        }

        System.out.println("===============================");
    }


    public void printEdge(int node) {
        String s1 = Device.getCompName(node);

        Set<Integer> setI = edges.get(Integer.valueOf(node));
        Iterator<Integer> iter = setI.iterator();
        {
            while (iter.hasNext()) {
                int ii = iter.next().intValue();
                String s2 = Device.getCompName(ii);
                System.out.println(s1 + "-- edge -->" + s2);
            }
        }
    }

}// class

