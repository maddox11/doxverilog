package xml.graph;

import java.util.*;

import xml.Device;

public class SCCTarjan {

	private static Map<Integer, LinkedHashSet<Integer>> graph;
	private static boolean[] visited;
	private static Stack<Integer> stack;
	private static int time;
	private static int[] lowlink;
	private static List<List<Integer>> components;

	public static  Set<String> scc(Graph g) {
		Set<String> eli = new LinkedHashSet<String>();
		List<List<Integer>> cycles = scc(g.getEdges());
		setSccCmp(cycles,eli);
		debug(cycles);
		g.bCycles = containsSCC(cycles);
		g.sccGraph = cycles;
		return eli;
	}

	public static boolean containsSCC(List<List<Integer>> scc) {
		for (List<Integer> li : scc)
			if (li.size() > 1)
				return true;

		return false;
	}

	public static List<List<Integer>> scc(
			Map<Integer, LinkedHashSet<Integer>> gr) {
		int n = gr.size();
		graph = gr;
		visited = new boolean[n + 1];
		stack = new Stack<>();
		time = 0;
		lowlink = new int[n + 1];
		components = new ArrayList<>();

		for (int u = 0; u < n; u++)
			if (!visited[u])
				dfs(u);

		return components;
	}

	private static void dfs(int u) {
		LinkedHashSet<Integer> lis=graph.get(u);
		lowlink[u] = time++;
		visited[u] = true;
		stack.add(u);
		if(lis==null)
			return;
		
		boolean isComponentRoot = true;


				for (int v : lis) {
				if (!visited[v]) {
					dfs(v);
				}
				if (lowlink[u] > lowlink[v]) {
					lowlink[u] = lowlink[v];
					isComponentRoot = false;
				}
			}

		if (isComponentRoot) {
			List<Integer> component = new ArrayList<>();
			while (true) {
				int x = stack.pop();
				component.add(x);
				lowlink[x] = Integer.MAX_VALUE;
				if (x == u) {
					break;
				}
			}
			if(component.size()>1)
			  components.add(component);
		}
	}

	
	/**
	 * fügt alle Komponenten, die sich in einer SCC befinden, in eine Liste ein
	 * @param scc SCC
	 * @param eli LinkedList
	 */
	public static void setSccCmp(List<List<Integer>> scc,Set<String> eli) {
		int set=1;
		for (List<Integer> li : scc) {
			if(li.size()==1) continue;
		//	System.out.println("==========================================");
			for (Integer ii : li) {
				String s = Device.getCompName(ii);
	//			System.out.println("SCC:"+s+" "+set);
				eli.add(s);
			}
			set++;
		//	System.out.println("==========================================");
			}
	}
	
	public static void debug(List<List<Integer>> scc) {
		int index = 0;
		System.out.println("==================== SCC ================");
		for (List<Integer> li : scc) {
			if(li.size()==1) continue;
			System.out.println();
			System.out.print("[" + index + "]");
			for (Integer ii : li) {
				String s = Device.getCompName(ii);
			}
			index++;
		}
	}
	
}
