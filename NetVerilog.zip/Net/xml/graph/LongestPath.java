package xml.graph;

import java.util.*;
import java.util.Map.*;

import xml.Entity;

public class LongestPath {

    public HashMap<Integer,HashSet<Integer>> arEl=null;

	public LongestPath(Map<Integer,Integer> pathes) {
		arEl = new HashMap<>(pathes.size());
		Set<java.util.Map.Entry<Integer,Integer>> iset=pathes.entrySet();
		for (java.util.Map.Entry<Integer,Integer> e : iset) {
            int k=e.getValue();
			int v=e.getKey();
			HashSet<Integer> hs=arEl.get(k);
			if(hs==null) {
				hs = new HashSet<>();
				arEl.put(k, hs);
			}
			hs.add(v);
		}
	}

	public static int computeAllLongestPath4(Graph g, List<Integer> topoG,
			int source, int dest) {

		HashMap<Integer,Integer> dist=new HashMap<>(topoG.size() + 1);
		HashMap<Integer,Integer> longdist=new HashMap<>(topoG.size() + 1);

		Stack<Integer> stack = new Stack<>();

		for (int i:topoG) {
			dist.put(i,Integer.MIN_VALUE);
			longdist.put(i,-1);
		}

		dist.put(source,0);

		for (int ii : topoG)
			stack.add(ii);

		// System.out.println(stack);
    	while (!stack.isEmpty()) {
			int u = stack.remove(0);
			if (dist.get(u) != Integer.MIN_VALUE) {
				for (int v : g.getEdges().get(u)) {
					if (dist.get(v) < dist.get(u) + 1) {
						dist.put(v,dist.get(u) + 1);
						longdist.put(v,u);
					}// if
					if (v == dest)
						break;
				}// for
			}
		}
		return getLongestPath(longdist, source, dest);
	}


	public static Map<Integer, Integer> computeAllLongestPath1(Graph g, int source) {
		List<Integer> lli = TopologicalSort.topoSort(g);
		Map<Integer, Integer> edges = new TreeMap<>();
		//int[] li = new int[g.getEdges().size() ];
       	Set<Integer> setI = g.getEdges().keySet();
		Iterator<Integer> iter = setI.iterator();

		while (iter.hasNext()) {
			int ii = iter.next();
			int val = computeAllLongestPath4(g, lli, source, ii);
			edges.put(ii,val);
		}

		return edges;
	}


	public static void printLongestPath(Map<Integer,Integer> mm, PartGraph pg) {
		Set<java.util.Map.Entry<Integer,Integer>> kk=mm.entrySet();

		for(Entry<Integer,Integer> ei:kk){
			int id=ei.getKey();
			int dist=ei.getValue();
			Entity e=pg.getNode(id);
		//	System.out.println(e.getCompName()+" id "+id+" dist "+dist);
		}
	}

	public static int getLongestPath(HashMap<Integer,Integer> paths, int source, int dest) {
		int i = dest;
		int counter = 0;
		// System.out.println(Device.getCompName(i));
		while (i != source) {
			i = paths.get(i);
			if (i < 0 ) {
				counter = Integer.MAX_VALUE - 1;
				break;
			}
			counter++;
			// System.out.println(Device.getCompName(i));
		}
		return counter;
	}

	/**
	 * Speichert den laengsten Pfad von jeden Knoten bis zum SO-Knoten
	 * @author hake
	 *
	 */
	
	public class ListElem implements Comparator<ListElem> {
		public String name = "";
		public int idd = 0;
		public int index = 0;
		public int longPath = 0;
		//List<String> path = null;

		public ListElem(String n, int id, int ind, int lp) {
			name = n;
			idd = id;
			index = ind;
    		longPath = lp;
		}

		public int compare(ListElem arg0, ListElem arg1) {
			// TODO Auto-generated method stub
			assert(arg0!=null && arg1 != null);

			if (arg0.longPath < arg1.longPath)
				return 1;
			else if (arg0.longPath == arg1.longPath)
				return 0;
			else
				return -1;
		}

	}

}// class
