package xml;

import java.awt.Rectangle;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.time.Instant;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import java.awt.geom.*;
import java.awt.Point;

// special
import xml.geom.Entity2D;
import xml.geom.Entity2D.Port2D;
import xml.geom.LineXY;
import xml.graph.*;
import xml.geom.PointXY;

public class NetlistWriter {


    private final int UP = 1;
    private final int DOWN = 2;
    private final int LEFT = 3;
    private final int RIGHT = 4;

    private Constants co;

    private PrintStream ps = null;
    private final String qu = "\"";
    private final String style = " style=\"font-family:Arial; font-size:14px;font-weight:plain;\">";
    private final String eText = "</text>";
   // private final String fill = "fill=\"lightgrey\" stroke=\"blue\"/>";

    protected static String[] colCom = {"green", "red", "cyan", "violet",
            "yellow", "navy", "brown", "indigo", "crimson", "gold", "ivory",
            "cyan", "maroon", "beige"};


    private String outFile = null;

    // "Graph_"+vv+".svg"
    public NetlistWriter(String file) {

        outFile = file + Utility.getTime() + ".svg";
        try {
            ps = new PrintStream(new FileOutputStream(outFile));
        } catch (Exception e) {
            System.err.println(e.getMessage());
            ps.close();
        } finally {
            System.out.println("finished writing file: " + file);
        }

    }

    public void drawSignalPath(NetListContainer cont) {
        //  svg.printPolyLine(ll);
        List<LineXY> ll = cont.getSignalPath();

        // boolean bt = LineXY.containsBus(ll);

        for (LineXY line : ll) {
            line.setBusLine(cont.isBus());
            printLine(line);
        }

        LineXY.assignPoints(ll);
        for (LineXY line : ll) {

            boolean bstart = (line.getArrowUP() == (Constants.ARROW_Start)) && line.isBusLine();

            boolean bend = (line.getArrowDOWN() == (Constants.ARROW_End)) && line.isBusLine();

            boolean barr = (line.getArrowUP() == (Constants.ARROW_Start)) && !line.isBusLine();
            boolean barrend = (line.getArrowDOWN() == (Constants.ARROW_End)) && !line.isBusLine();

            if (line.getCrossPoint() == Constants.CROSS_POINT) {
                printCircle((int) line.x1, (int) line.y1, 6, "black", "1");

                continue;
            }


            String text = line.getBusName1();
            String text1 = line.getBusName2();


            if (line.getStartType() == LineXY.CROSSPOINT) {
                if (line.isBusLine() && line.isInPort) {
                    writeText(text, (int) line.x1, (int) line.y1);
                    printTriangle((int) line.x1, (int) line.y1, 4);
                } else
                    printCircle((int) line.x1, (int) line.y1, 6, "black", "1");
            }


            if (line.getEndType() == LineXY.CROSSPOINT) {
                writeText(text, (int) line.x2, (int) line.y2);
                printCircle((int) line.x2, (int) line.y2, 6, "black", "1");
            }

            if (bend) {
                printTriangle((int) line.x2, (int) line.y2, Constants.DOWN.getValue());
                writeText(text1, (int) line.x2, (int) line.y2);
            }

            if (bstart) {
                printTriangle((int) line.x1, (int) line.y1, Constants.UP.getValue());
                writeText(text, (int) line.x1, (int) line.y1);
                //  svg.printQuader((int) line.x1 - 4, (int) line.y1, 8, "blue", "1");
            }


            if (barr) {
                //  svg.printTriangle((int) line.x1, (int) line.y1, Constants.UP.getValue());
                // svg.printCircle((int) line.x1, (int) line.y1, 6, "black", "1");
                printQuader((int) line.x1 - 4, (int) line.y1 - 4, 8, "black", "1");
                writeText(text, (int) line.x1, (int) line.y1);
            }

            if (barrend) {
                printQuader((int) line.x2 - 4, (int) line.y2 - 4, 8, "black", "1");
                writeText(text1, (int) line.x2, (int) line.y2);
            }
        }
    }

    public void writeHeader(String width, String height) {
        System.out.println("width..: " + width + " height:" + height);
        String w = qu + width + qu;
        String h = qu + height + qu;
        ps.println("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>");
        ps.println("<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20010904//EN\"");
        ps.println("\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">");
        ps.print("<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"");
        ps.print(" width=" + w);
        ps.println(" height=" + h + ">");
    }

    public void writeComment(String comment) {
        ps.println("<!--");
        ps.println(comment);
        ps.println("-->");
    }

    // id ="180Data0x0"
    //oo[0] = hf.fi;
    //oo[1] = se;
    public String createId(String id) {
        return "id=" + quot(id);
    }

    public boolean createRef(Entity2D e2d) {
        Entity ent=e2d.getEntity();
        String name=ent.getCompName();

     //   if(ent.isOutputPin())
      //      assert(false);

        if(ent.isInputPin())
            return false;
/*
        Href ref=Href.findPort(name);
         if(ref==null)
             return false;
*/
        List<Object[]> ls= Href.findInputPorts(name);
        if(ls==null || ls.isEmpty())
            return false;
        String s1="<a xlink:href=";
        Object[] oo=ls.get(0);
        String s2=(String)oo[0];
        String s3=(String)((java.util.Map.Entry)oo[1]).getKey();
        String s4= quot(s2+"#"+s3)+">";
        ps.println(s1+s4+">");
        return true;
   }

    public void endA() {
        ps.println("</a>");
    }
 /**
    <a xlink:href="Graph_3__2020-04-20.svg#180Data0x0">
<text x="30658" y="2371"  style="font-family:Arial; font-size:14px;font-weight:plain;">
    txcirq
            </text>
</a>
*/

   public void writeText(String s) {
       ps.println(s);
   }

   public void writeText(String str, int x1, int y1) {
        writeText(str, null, x1, y1);
    }

    public void writeText(String str, String id, int x1, int y1) {

        if (str == null || str.isEmpty())
            return;

        try {

            String x = Integer.toString(x1);
            String y = Integer.toString(y1);

            if (id == null)
                ps.println("<text x=" + quot(x) + " y=" + quot(y) + " " + style);
            else {
                id = createId(str);
                ps.println("<text " + id + " x=" + quot(x) + " y=" + quot(y) + " " + style);
            }
            ps.println(str + " " + eText);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private String intT(int i) {
        String s = Integer.toString(i);
        return s;
    }

    private String quotInt(double i) {
        String s = Integer.toString((int) i);
        return s;
    }

    private String quotInt(int i) {
        String s = quot(Integer.toString(i));
        return s;
    }

    public String quot(String s) {
        return qu + s + qu;
    }

    public void endSVG() {
        ps.println("</svg>");
        ps.close();
    }


    public void printRect(int x, int y, Rectangle r, String color, String strok) {
        ps.println();
        ps.print("<rect x=" + quotInt(x) + " y=" + quotInt(y));
        ps.print(" width=" + quotInt((int) r.getWidth()) + " height="
                + quotInt((int) r.getHeight()));
        ps.print(" rx=" + quotInt(5));
        ps.print(" ry=" + quotInt(5));
        ps.println(" fill=" + quot(color) + " stroke=" + quot(strok) + "/>");
    }


    public void printLine(LineXY li) {

        if (li.isBusLine() && li.isInPort) {
            printLine((int) li.x1, (int) li.y1, (int) li.x2, (int) li.y2, "green", 3);
            return;
        }

        if (li.isBusLine() && li.isOutport) {
            printLine((int) li.x1, (int) li.y1, (int) li.x2, (int) li.y2, "green", 3);
            return;
        }

        if (li.isBusLine())
            printLine((int) li.x1, (int) li.y1, (int) li.x2, (int) li.y2, "green", 3);
        else
            printLine((int) li.x1, (int) li.y1, (int) li.x2, (int) li.y2, "black", 1);

    }


    public void printLine(int x, int y, int x1, int y1, String strok, int width) {
        ps.print("<line x1=" + quotInt(x) + " y1=" + quotInt(y));
        ps.print(" x2=" + quotInt(x1) + " y2=" + quotInt(y1));
        ps.print(" stroke=" + quot(strok));
        ps.print(" stroke-linecap=" + quot("round"));
        if (width != 0)
            ps.print(" stroke-width=" + quotInt(width));

        ps.println("/>");
    }

    private void printPoint(int x, int y) {
        ps.print(" " + intT(x) + "," + intT(y) + " ");
    }


    public void printTriangle(int x, int y, int dir) {
        ps.println();
        ps.print("<polygon points=\"");

        switch (dir) {
            case (RIGHT):
                printPoint(x, y + 6);
                printPoint(x, y - 6);
                printPoint(x + 10, y);
                break;
            case (LEFT):
                printPoint(x, y + 8);
                printPoint(x, y - 8);
                printPoint(x - 8, y);
                break;
            case (UP):
                printPoint(x, y);
                printPoint(x - 6, y + 8);
                printPoint(x + 6, y + 8);
                break;
            case (DOWN):
                printPoint(x, y);
                printPoint(x + 6, y - 8);
                printPoint(x - 6, y - 8);
                break;

        }
        ps.println("\"");
        ps.println(" fill=\"black\"" + " stroke=\"none\"/>");
    }

    // <circle cx="205" cy="100" r="80" fill="yellow" stroke="black" />
    public void printCircle(int x, int y, int rad, String col, String stroke) {
        ps.println();
        ps.print("<circle cx=" + quotInt(x) + " cy=" + quotInt(y));
        ps.print(" r=" + quotInt(rad));
        ps.println(" fill=" + quot(col) + " stroke=" + quot(stroke) + "/>");
    }

    public void printQuader(int x, int y, int rad, String col, String strok) {

        ps.println();
        ps.print("<rect x=" + quotInt(x) + " y=" + quotInt(y));
        ps.print(" width=" + quotInt(rad) + " height="
                + quotInt(rad));
        ps.println(" fill=" + quot(col) + " stroke=" + quot(strok) + "/>");

    }

    public void writeEntity(Entity2D e2d, int x, int y, String color,
                            boolean opaque) {
        if (opaque)
            ps.println("<g opacity=\"0\">");
        else
            ps.println("<g>");

        e2d.transform(x, y);

        int dx = (int) e2d.getInnerRect().getX();
        int dy = (int) e2d.getInnerRect().getY();

        printRect((int) e2d.getInnerRect().getX(), (int) e2d.getInnerRect()
                .getY(), e2d.getInnerRect(), color, "black");
        boolean b=createRef(e2d);
        writeText(e2d.getEntity().getCompName(), e2d.getEntity().getCompName(), dx, dy - 1);
        if(b)
        endA();
        writePorts(e2d);

        ps.println("</g>");

    }


    public void writePorts(Entity2D e2d) {
        // write input ports
        Enumeration<Port2D> enode = e2d.inP.elements();
        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            int x1 = (int) (po.getX() + e2d.maxIL - po.rec.getWidth());
            // printRect(x1,y1,po.rec,"none","none");
            writeText(po.getPortName(), x1, po.getY() - 1);
            printLine(po.getX(), po.getY() + 1, po.getX() + e2d.maxIL, po.getY() + 1,
                    "green", 3);
            printCircle(po.getX(), po.getY() + 1, 2, "black", "none");
        }

        enode = e2d.outP.elements();
        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            int x1 = (po.getX() - e2d.maxOL);
            // printRect(x1,y1,po.rec,"none","none");
            writeText(po.getPortName(), x1 + 2, po.getY() - 1);
            printLine(x1, po.getY() + 1, po.getX(), po.getY() + 1, "green", 2);
            printCircle(po.getX(), po.getY() + 1, 2, "black", "none");
        }
    }

}// class

