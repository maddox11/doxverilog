package xml;

import java.util.Map.Entry;
import java.util.*;

public class Href {
    public static List<Href> vList = new ArrayList<>();
    public String fi;
    private Hashtable<String, Entity> vt = new Hashtable<>();

    public Href(String fi, Hashtable<String, Entity> hs) {
        this.fi = fi;
        Set<Entry<String, Entity>> es = hs.entrySet();
        for (Entry<String, Entity> se : es) {
            if (se.getValue().isOutputPin() || se.getValue().isInputPin())
                if (Device.getEntity(se.getKey()) == null)
                    vt.put(se.getKey(), se.getValue());
        }
    }

    public static void addHref(Href ref) {
        vList.add(ref);
    }

    public static Href getHref(String n) {
        for (Href hf : vList) {
            if (hf.vt.containsKey(n))
                return hf;
        }
        return null;
    }

    public static List<String> getAllOutports() {
        List<String> li = new ArrayList<>();
        for (Href hf : vList) {
            Set<Entry<String, Entity>> es = hf.vt.entrySet();
            for (Entry<String, Entity> se : es) {
                if (se.getValue().isOutputPin())
                    li.add(se.getKey());
            }
        }
        return li;
    }

    public static List<String> getAllInports() {
        List<String> li = new ArrayList<>();
        for (Href hf : vList) {
            Set<Entry<String, Entity>> es = hf.vt.entrySet();
            for (Entry<String, Entity> se : es) {
                if (se.getValue().isInputPin())
                    li.add(se.getKey());
            }
        }
        return li;
    }

    public static List<Object[]> findOutputPorts(String port) {
        String[] tmp = port.split("_");
        tmp[0] = tmp[0].concat("_");
        CharSequence sc = tmp[0].subSequence(0, tmp[0].length());
        List<Object[]> li = new ArrayList<>();
        for (Href hf : vList) {
            Set<Entry<String, Entity>> es = hf.vt.entrySet();
            for (Entry<String, Entity> se : es) {
                if (se.getKey().contains(sc) && se.getValue().isOutputPin()) {
                    Object[] oo = new Object[2];
                    oo[0] = hf.fi;
                    oo[1] = se;
                    li.add(oo);
                    System.out.println("Input: " + port + " -> Output :" + se.getKey() + " " + hf.fi);
                }
            }
        }
        return li;
    }

    public static List<Object[]> findInputPorts(String port) {
        String[] tmp = port.split("_");
        tmp[0] = tmp[0].concat("_");
        CharSequence sc = tmp[0].subSequence(0, tmp[0].length());
        List<Object[]> li = new ArrayList<>();
        for (Href hf : vList) {
            Set<Entry<String, Entity>> es = hf.vt.entrySet();
            for (Entry<String, Entity> se : es) {
                if (se.getKey().contains(sc) && se.getValue().isInputPin()) {
                    Object[] oo = new Object[2];
                    oo[0] = hf.fi;
                    oo[1] = se;
                    li.add(oo);
                    System.out.println("Output: " + port + " -> Input :" + se.getKey() + " " + hf.fi);
                }
            }
        }
        return li;
    }


    public static Href findPort(String port) {
        for (Href hf : vList) {
            if (hf.vt.containsKey(port))
                return hf;
        }
        return null;
    }

    public static void debugAll() {
        vList.forEach(Href::debug);

    }

    public void debug() {
        System.out.println("<-------    -------->");
        Set<String> ss = vt.keySet();
        for (String s : ss)
            System.out.println(s + "     |       " + fi);

        System.out.println("<--------------->");
    }


}
