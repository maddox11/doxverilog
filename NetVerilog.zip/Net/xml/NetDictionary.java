package xml;

import java.util.*;

import xml.geom.*;

/**
 * Created by hake on 1/16/19.
 */
public class NetDictionary {

    private static NetDictionary netDict = null;

    private static ArrayList <NetNode> nodeL = new ArrayList <>();

    private NetDictionary() {
    }

    public static NetDictionary getInstance() {
        if (netDict == null)
            return new NetDictionary();

        return netDict;
    }

    public static void reset(){nodeL.clear(); }



    public void addNetNode(String e1, String po, String e2, String pi) {

        if (Device.getTopModuleName().equalsIgnoreCase(e1))
            e1 = po;

        if (Device.getTopModuleName().equalsIgnoreCase(e2))
            e2 = pi;

        nodeL.add(new NetNode(e1, po, e2, pi));
    }


    public List <NetNode> findInport(String ent, String pi) {

        ArrayList <NetNode> arr = new ArrayList <>();

        for (NetNode no : nodeL) {
            if (no.poEntity.equalsIgnoreCase(ent))
                if (no.po.equalsIgnoreCase(pi))
                    arr.add(no);
        }
        return arr;
    }

    public List <NetNode> findOutport(String ent, String pi) {

        ArrayList <NetNode> arr = new ArrayList <>();

        for (NetNode no : nodeL) {
            if (no.piEntity.equalsIgnoreCase(ent))
                if (no.pi.equalsIgnoreCase(pi))
                    arr.add(no);
        }
        return arr;
    }

    public String findPath(String from, String to, String port) {

        List <NetNode> net = findOutport(from, port);
        StringBuilder buf = new StringBuilder(from);
        buf.append(":");
        buf.append(port);
        buf.append("--?-> ");
        buf.append(to);
        buf.append(":");

        for (NetNode no : net) {
            if (no.poEntity.equalsIgnoreCase(to)) {
                buf.append(no.po);
            }
        }

        return buf.toString();
    }


    public List <NetNode> findOutPort(String ent, String pi) {
        List <NetNode> net = findOutport(ent, pi);
        return net;
    }

    public void debugAll() {
        for (NetNode no : nodeL)
            no.debug();
    }

    public static class NetNode {

        public String pi;
        public String piEntity;

        public String po;
        public String poEntity;

        public List<NetNode> netNode;

        public NetNode(String s, String s1, String s2, String s3) {
            poEntity = s;
            po = s1;
            piEntity = s2;
            pi = s3;
        }

        public NetNode clone() {
            return new NetNode(poEntity, po, piEntity, pi);
        }

        private void debug() {
       //     System.out.println("<" + poEntity + "::" + po + " --> " + piEntity + "::" + pi + ">");
            //  System.out.println("<" + piEntity + "::" + pi + " --> " + poEntity + "::" + po + ">");
        }
    }//NetNode
}
