package xml;

/**
 * Created by hake on 1/13/19.
 */
public enum Constants {
    UP(1),
    DOWN(2),
    LEFT(3),
    RIGHT(4),
    ARROW_Start(5),
    ARROW_End(6),
    CROSS_POINT(7),

    XCOOR(200),
    YCOOR(20),

    XSPACE(20),
    YSPACE(20),

    LINESPACE(24),//column widht+4 pixel
    LINEWIDTH(2),

    YCELLROW(85);

    private int value;

    public int getValue() {
        return value;
    }

    Constants(int value) {
        this.value = value;
    }
}
