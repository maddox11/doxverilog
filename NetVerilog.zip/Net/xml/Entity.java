package xml;

import xml.geom.Bus;
import xml.geom.Port;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;
import java.util.*;

public class Entity {

    public String name = ""; // and | or | xor
    private String compName; // U10 | U1 etc..
    public String lpm_type = ""; // lpm_and | top_modul (entity_name) |
    private int idd;


    protected int lpm_cvalue = -1;
    protected int lpm_size = -1;
    protected int lpm_width = -1;

    private Vector<Port> inPort = new Vector<>();
    private Vector<Port> outPort = new Vector<>();


    // default Entity(input/output)
    public Entity(String def) {
        compName = def;
    }

    public Entity(String def, int idd) {
        compName = def;
        this.idd = idd;
    }

    public Entity(String n, String m) {
        initEntity(n);
        compName = m;
    }

    public void initEntity(String name) {
        XMLComponent comp = Device.getComponentList().get(name);
        if (comp == null) {
            System.out.println("uninitialized component:" + name);
            System.exit(0);
        }

        this.name = comp.name;
        this.lpm_type = comp.lpm_type.replace("\"", "");
        this.lpm_cvalue = comp.lpm_cvalue;
        this.lpm_size = comp.lpm_size;
        this.lpm_width = comp.lpm_width;

  //      comp.inPort.stream().forEach(s->addInport(s));

        Iterator<String> it = comp.inPort.iterator();
        while (it.hasNext()) {
            addInport(it.next());
        }

        it = comp.outPort.iterator();
        while (it.hasNext()) {
            addOutPort(it.next());
        }

        Set<String> ss = comp.inBuses.keySet();
        Iterator<String> iter = ss.iterator();


        while (iter.hasNext()) {
            String s1 = iter.next();
            addBuses(s1, comp.inBuses.get(s1), -1);
        }

        ss = comp.outBuses.keySet();
        iter = ss.iterator();

        while (iter.hasNext()) {
            String s1 = iter.next();
            addBuses(s1, comp.outBuses.get(s1), 1);
        }
    }

    public Vector<Port> getAllPorts() {
        Vector<Port> op = new Vector<Port>(inPort);
        op.addAll(outPort);

        return op;
    }

    public LinkedHashSet<String> getOutPortEntities() {
        LinkedHashSet<String> po = new LinkedHashSet<>();
        for (Port pp : outPort) {
            Vector<Port> vp = pp.getLinkOutput();
            for (Port pt : vp) {
                po.add(pt.getEntity().getCompName());
            }
        }
        return po;
    }

    public LinkedHashSet<String> getInputPortEntities() {
        LinkedHashSet<String> po = new LinkedHashSet<>();
        NetDictionary nc = NetDictionary.getInstance();
        for (Port pp : inPort) {
            String pi = pp.getPortName();
            List<NetDictionary.NetNode> net = nc.findOutPort(this.compName, pi);
            assert (net.size() <= 1);
            if (!net.isEmpty()) {
                po.add(net.get(0).poEntity);
            }
        }
        return po;
    }

    public Vector<Port> getAllOutPorts() {
        return outPort;
    }


    public Vector<Port> getAllInputPorts() {
        return inPort;
    }

    public void addInport(String s) {
        inPort.add(new Port(s, this, -1));
    }

    public void addOutPort(String s) {
        outPort.add(new Port(s, this, 1));
    }

    public boolean checkPort(HashSet<Integer> hs, boolean inport) {
        if (inport) {
            for (Port pp : getAllInputPorts()) {
                Vector<Port> vec= pp.getLinkInput();
                for (Port po : vec) {
                    int idd = po.getEntity().getIdd();
                    if (!hs.contains(idd)) {
                        System.out.println(" remove input port:");
                        po.debug();
                        vec.remove(po);
                        return true;
                    }
                }
            }
            return false;
        }
        if (!inport) {
            for (Port pp : getAllOutPorts()) {
                Vector<Port> vec= pp.getLinkOutput();
                for (Port po : vec) {
                    int idd=po.getEntity().getIdd();
                    if (!hs.contains(idd)) {
                        System.out.println(" remove output port:");
                        po.debug();
                        vec.remove(po);
                        return true;
                    }
                }
            }
            return false;
        }
     return false;
    }// checkPort

    public boolean removePort(String port) {
        for (Port pp : outPort) {
            if (pp.getPortName().equalsIgnoreCase(port)) {
                return outPort.remove(pp);
            }
        }
        return false;
    }

    public void addBuses(String s, ArrayList<String> al, int dir) {
        if (dir == 1)
            outPort.add(new Bus(s, this, 1, al));
        if (dir == -1)
            inPort.add(new Bus(s, this, -1, al));

    }

    public Port getPort(String n) {
        Port p = findPort(inPort, n);
        if (p != null) {
            return p;
        }
        return findPort(outPort, n);
    }

    public int getIdd() {
        return idd;
    }

    public void setIdd(int idd) {
        this.idd = idd;
    }


    public String getLpmType() {
        return lpm_type;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String s) {
        compName = s;
    }

    public boolean isInputPin() {
        return name.equalsIgnoreCase("input");
    }

    public boolean isOutputPin() {
        return name.equalsIgnoreCase("output");
    }

    public Port getOutputPort(String n) {
        return findPort(outPort, n);
    }

    public Port getInputPort(String n) {
        return findPort(inPort, n);
    }


    private Port findPort(Vector<Port> vec, String name) {
        Iterator<Port> it = vec.iterator();
        while (it.hasNext()) {
            Port p = it.next();
            String ss = name;

            if (p.isBus()) {
                Iterator<Port> it1 = ((Bus) p).getPortList().iterator();
                while (it1.hasNext()) {
                    Port p1 = it1.next();
                    if (p1.getPortName().equalsIgnoreCase(ss)) {
                        return p1;
                    }
                }
            }

            if (p.getPortName().equalsIgnoreCase(ss)) {
                return p;
            }

        }//while
        return null;
    }


    // return true if this port is an input/output port
    // of the top entity.
    public static Port isInOutPort(String port) {
        Entity ee = Device.getTopEntity();
        Port xml = ee.getInputPort(port);
        if (xml != null)
            return xml;
        xml = ee.getOutputPort(port);

        if (xml != null)
            return xml;

        return null;
    }



    public Port[] hasOutputLinkTo(Entity to) {
        Port[] pv = new Port[2];
        Vector<Port> pvec = getAllOutPorts();
        for (Port pp : pvec) {
            for (Port port : pp.getLinkOutput()) {
                if (port.getEntity().getCompName().equalsIgnoreCase(to.getCompName())) {
                    //  pp.debug();
                    // System.out.println("************************************");
                    pv[0] = pp;
                    pv[1] = port;
                    return pv;
                }
            }
        }
        return null;
    }

    public Entity deepClone() {
        Entity ee = new Entity(this.compName);

        ee.idd = idd;
        ee.name = name;
        ee.lpm_type = lpm_type;

        ee.lpm_cvalue = lpm_cvalue;
        ee.lpm_size = lpm_size;
        ee.lpm_width = lpm_width;

    //    if(ee.getCompName().equalsIgnoreCase("U463"))
    //        System.out.println();

        for (Port p : outPort)
            ee.outPort.add(p.clonePort());

        for (Port p : inPort)
            ee.inPort.add(p.clonePort());

        return ee;
    }

    public void debug(boolean dir) {
        if (dir) {
            for (Port pi : inPort) {
                pi.debug();
            }
            return;
        }
        for (Port po : outPort) {
            po.debug();
        }
    }

}

