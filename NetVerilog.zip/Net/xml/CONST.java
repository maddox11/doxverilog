package xml;

/**
 * Created by hake on 5/27/18.
 */
public interface CONST {
     int XCOOR=200;
     int YCOOR=20;

     int XSPACE = 20;
     int YSPACE = 20;

     int LINESPACE = 24;//column widht+4 pixel
     int LINEWIDTH = 2;

     int YCELLROW = 85;

}

