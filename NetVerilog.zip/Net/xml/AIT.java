package xml;

import java.util.ArrayList;

import xml.geom.*;


import java.util.List;
import java.util.Optional;


public class AIT {

    private static List<Interval> queries = null;
    public Interval root = null;

    public int dimMax = 0;

    public AIT() {
    }

    public AIT(List<LineXY> root, boolean hor, int line) {
        buildIntervalTree(root, hor, line);
    }

    public AIT(List<LineXY> liList) {
        List<Interval> liIn = new ArrayList<Interval>();
        for (LineXY line : liList) {
            if (line.isHorizontalLine()) {
                liIn.add(new Interval((int) line.x1, (int) line.x2, line));
            } else
                liIn.add(new Interval((int) line.y1, (int) line.y2, line));
        }

        for (Interval inv : liIn)
            root = insertNode(root, inv);

    }

    public static void resetQ() {
        if (queries != null)
            queries.clear();
    }

    public Interval insertNode(
            Interval tmp, Interval newNode) {
        if (tmp == null) {
            tmp = newNode;
            return tmp;
        }

        if (newNode.getEnd() > tmp.getMax()) {
            tmp.setMax(newNode.getEnd());
        }

        if (tmp.compareTo(newNode) <= 0) {

            if (tmp.getRight() == null) {
                tmp.setRight(newNode);
            } else {
                insertNode(tmp.getRight(), newNode);
            }
        } else {
            if (tmp.getLeft() == null) {
                tmp.setLeft(newNode);
            } else {
                insertNode(tmp.getLeft(), newNode);
            }
        }
        return tmp;
    }

    public void printTree(Interval tmp) {
        if (tmp == null) {
            return;
        }

        if (tmp.getLeft() != null) {
            printTree(tmp.getLeft());
        }

        //     System.out.print(tmp);

        if (tmp.getRight() != null) {
            printTree(tmp.getRight());
        }
    }

    public void intersectInterval(Interval tmp, Interval i, List<Interval> res) {

        if (tmp == null) {
            return;
        }

        long a = tmp.getStart();
        long b = tmp.getEnd();

        long y = i.getStart();
        long z = i.getEnd();

        Optional<List<Interval>> rr= Optional.of(res);

        if (!(z < a || b < y)) {

             if (res == null) {
                res = new ArrayList<>();
            }
            res.add(tmp);
        }

        if ((tmp.getLeft() != null) && (tmp.getLeft().getMax() >= i.getStart())) {
            intersectInterval(tmp.getLeft(), i, res);
        }

        intersectInterval(tmp.getRight(), i, res);
    }

    public void buildIntervalTree(List<LineXY> li, boolean hor, int line1) {

        List<Interval> liIn = new ArrayList<Interval>();

        for (LineXY line : li) {
            if (hor) {
                liIn.add(new Interval((int) line.x1, (int) line.x2, line));
            } else
                liIn.add(new Interval((int) line.y1, (int) line.y2, line));
        }

        for (Interval inv : liIn)
            root = insertNode(root, inv);

        int v = checkQueries(liIn);

        dimMax = v;

    }

    //  public int performQueries

    public int checkQueries(List<Interval> queries) {

        List<Interval> over = new ArrayList<>();
        int max = 0;
        for (Interval i : queries) {
            over.clear();
            intersectInterval(root, i, over);
            int len = over.size();
            max = Math.max(max, len);
        }

        return max;
    }

    public void printInterval(List<Interval> ii) {
        for (Interval i : ii) {
            System.out.println(i.toString());
        }
    }

    public List<LineXY> intQuery(int start, int end, boolean hor) {
        List<Interval> over = new ArrayList<>();
        Interval iv = new Interval(start, end);
        intersectInterval(root, iv, over);
        List<LineXY> ll = new ArrayList<>();
        for (Interval inn : over)
            if (hor && inn.li.isHorizontalLine())
                ll.add(inn.li);
            else if (!hor && inn.li.isVerticalLine())
                ll.add(inn.li);
        return ll;
    }


    static class Interval implements Comparable<Interval> {

        private long start;
        private long end;
        private long max;
        private Interval left;
        private Interval right;
        public LineXY li = null;

        public void setStart(long start) {
            this.start = start;
        }

        public void setEnd(long end) {
            this.end = end;
        }

        public void setMax(long max) {
            this.max = max;
        }

        public void setLeft(Interval left) {
            this.left = left;
        }

        public void setRight(Interval right) {
            this.right = right;
        }

        public Interval(long start, long end) {

            this.start = start;
            this.end = end;
            this.max = end;
        }

        public Interval(long start, long end, LineXY li) {

            this.start = start;
            this.end = end;
            this.max = end;
            this.li = li;
        }

        public String toString() {
            return "[" + this.getStart() + "; " + this.getEnd() + ", "
                    + this.getMax() + "]";
        }

        public long getStart() {
            return start;
        }

        public long getMax() {
            return max;
        }

        public Interval getLeft() {
            return left;
        }

        public Interval getRight() {
            return right;
        }

        @Override

        public int compareTo(Interval i) {
            if (this.start < i.start) {
                return -1;
            } else if (this.start == i.start) {
                return this.end <= i.end ? -1 : 1;
            } else {
                return 1;
            }
        }

        public long getEnd() {
            return end;
        }


    }
}//class


