package xml;

import java.awt.Dimension;

import xml.graph.PartGraph;

import java.util.*;

import xml.geom.Entity2D.Ent2DNode;
import xml.geom.Entity2D.E2DCont;
import xml.graph.*;

import xml.geom.*;


public class NetListBuilder {

    public Hashtable<Integer, Integer> columnTable = new Hashtable<>();
    public Hashtable<Integer, Integer> rowTable = new Hashtable<>();
    private Hashtable<Integer, VChannel> xCoorH = new Hashtable<>();
    private Hashtable<Integer, HChannel> yCoorH = new Hashtable<>();
    // Integer : line of x-column x=20 |------------------|
    private Dimension layoutDimension;
    private int ycoor = 0;
    private int xcoor = 0;
    private Graph gr = null;
    private PartGraph pg = null;


    public NetListBuilder(PartGraph pg, LongestPath lg, NetlistWriter svg) {
        this.pg = pg;
        initMap(lg);
        System.out.println("================ <assign input pins>=========");
        assignInputPins();
        System.out.println("================ <setYCoord>=========");
        setYCoord();

        System.out.println("================ <set row column>=========");
        setRowCol();
        System.out.println("================ <bubble_sort_placement>=========");
        bubbleSortPlacement();
        System.exit(99);
        System.out.println("================ <build row table>=========");
        buildRowTable();
        System.out.println("================ <prelayout ciruit>=========");
        preLayoutCircuit();
        System.out.println("================ <compute line space>=========");
        computeSignalLines();
        System.out.println("================ <build singnal pathes > =========");
        builAllSignalPathes();
        System.out.println("================ <compute line space >=========");
        computeLineSpace();
        System.out.println("================ <calculateYRowtable >=========");
        calcYRowTable();
        System.out.println("================ <layout ciruit>=========");
        layoutCircuit(svg);
        System.out.println("================ <draw all preview pathes>=========");
        drawAllPreviewPathes(null);
        System.out.println("================ <recompute linespace>=========");
        reComputeLineSpace();
        System.out.println("================ <postlayout ciruit>=========");
        postLayoutCircuit(svg);
        System.out.println("================ <rebuild row table >=========");
        buildRowTable();
        drawAllPreviewPathes(svg);
        System.out.println("================ <draw signal pathes>=========");
        drawSignalPath(svg);
        System.out.println("================ <reset special list>=========");
        HChannel.reset();
        VChannel.reset();
        Entity2D.E2DCont.reset();
        AIT.resetQ();
        NetListContainer.reset();
    }

    /**
     * @return largest column
     */

    public static int getMaxColumnSize() {
        int mSize = 0;
        Iterator<List<Ent2DNode>> coll = E2DCont.getListIterEnt2D();
        while (coll.hasNext()) {
            List<Ent2DNode> cc = coll.next();
            for (Ent2DNode com : cc) {
                mSize = Math.max(mSize, com.endRow);
            }
        }
        return mSize;
    }

    public static boolean intersecComp(LineXY li, int xcoor, int xstart, int xend) {
        // int sum=0;
        assert (li.isHorizontalLine());

        List<Ent2DNode> col = E2DCont.getCrossList().get(xcoor);
        if (col == null)
            return false;
        for (Ent2DNode c : col) {
            if (c.xDist < xstart || c.xDist > xend)
                continue;
            java.awt.Rectangle rec2D = c.getE2d().getInnerRect();
            if (li.intersects(rec2D)) {
                return true;
            }
        }
        return false;
    }

    public static int[] getMinMaxY(List<PointXY> pinList) {
        int[] var = new int[2];
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (PointXY pt : pinList) {
            java.awt.Point p1 = Entity2D.getPortXY(pt.idd, pt.pin);
            min = Math.min(min, (int) p1.getY());
            max = Math.max(max, (int) p1.getY());
        }

        var[0] = min;
        var[1] = max;
        return var;
    }

    public void bubbleSortPlacement() {
        NetDictionary net = NetDictionary.getInstance();

        int ll = E2DCont.getNodesize();
        int index = ll - 2;

        for (int col = index; col >= 0; col--) {
            List<Ent2DNode> nodeL = E2DCont.getListAt(col);
            if (nodeL.isEmpty())
                continue;

            ListIterator<Ent2DNode> cmpNode = nodeL.listIterator();
            int yStart=nodeL.get(0).yDist;
            while (cmpNode.hasNext()) {
                Ent2DNode e2d = cmpNode.next();
                Entity ee = e2d.getEntity();
                int in = 0;
                if (ee.lpm_type.compareToIgnoreCase("input") == 0) {
                    Vector<Port> pv = ee.getAllOutPorts();
                    for (Port p : pv) {
                        Vector<Port> poo = p.getLinkOutput();
                        if (poo == null)
                            continue;
                        in += poo.size();
                    }
                    e2d.bubbleValue = in * 100.0;
                    System.out.println("Input: " + ee.getCompName() + " Bubble:" + e2d.bubbleValue);
                    continue;
                }

                double num = 0.0;
                int inports = 0;
                Vector<Port> pv = ee.getAllInputPorts();
                for (Port p : pv) {
                    List<NetDictionary.NetNode> ntd = net.findOutPort(ee.getCompName(), p.getPortName());
                    if (ntd == null)
                        continue;
                    inports += ntd.size();
                    for (NetDictionary.NetNode nd : ntd) {
                        Ent2DNode hz = E2DCont.getEnt2DNode(nd.poEntity);
                        if (hz == null)
                            continue;
                        num += hz.bubbleValue;
                    }
                }

                if (inports == 0)
                    inports = 1;
                e2d.bubbleValue = num / (double) inports;
                System.out.println("Input: " + ee.getCompName() + " Bubble:" + e2d.bubbleValue + " " + e2d.xDist + " " + e2d.yDist);

            }//while
            Collections.sort(nodeL);

            for (Ent2DNode ee : nodeL) {
              ee.yDist=yStart;
              ee.startRow=ee.yDist;
              ee.endRow=ee.startRow+ee.spanRow-1;
              yStart=ee.endRow+1;
            }

            Enumeration<Ent2DNode> en = E2DCont.getEnt2NodeEnum();
            while (en.hasMoreElements()) {
                Ent2DNode c = en.nextElement();
                c.getE2d().setPortRow(CONST.YCELLROW, c);
            }
        }//for
    }

    // private
    public void initMap(LongestPath lp) {
        layoutDimension = new Dimension(500, 200);
        gr = pg.getPartGraph();
        checkDisconnectComp(lp);
        buildMap(lp);
    }

    public String getName(String str) {

        int len = NetlistWriter.colCom.length;

        if (str == "###") {
            return "black";// NetlistWriter.colCom[2 % len];
        }

        int i = findSCC(str);
        if (i >= 0)
            return NetlistWriter.colCom[i % len];

        return null;
    }

    /**
     * transformiert die LongestPath.ListElem[] liElem in einen Hashtable von
     * Komponenten
     */
    public void buildMap(LongestPath lp) {
        int tot = 0;
        int max = Integer.MIN_VALUE;
        final int MAX = Integer.MAX_VALUE - 1;
        Vector<String> v1 = null;
        Hashtable<Integer, Vector<String>> entityMap = new Hashtable<>();
        lp.arEl.remove(MAX);

        for (int i : lp.arEl.keySet())
            max = Math.max(max, i);


        for (int i : lp.arEl.keySet()) {
            ArrayList<Ent2DNode> ak = new ArrayList<>();
            HashSet<Integer> hss = lp.arEl.get(i);
            tot += hss.size();
            for (int k : hss) {
                Entity enode = pg.getVertics().get(k);
                Entity2D e2d = new Entity2D(enode);
                Ent2DNode cm = e2d.createEnt2DNode(i);
                //   System.out.println(cm.xDist+" --!!-- "+enode.getCompName());
                ak.add(cm);
                E2DCont.addEnt2DNode(cm, enode.getCompName());
            }
            E2DCont.addEnt2DNodeList(ak, i);
        }// for

        for (int j = 0; j <= max; j++) {
            if (E2DCont.getListAt(j) == null) {
                E2DCont.addEnt2DNodeList(new ArrayList<>(), j);
            }
        }


        System.out.println("total size: " + tot);
    }// buildeMap

    private void resetComponentLayout() {
        Iterator<Ent2DNode> en = E2DCont.getEnt2NodeIter();
        while (en.hasNext()) {
            Ent2DNode c = en.next();
            c.getE2d().resetLayout();
        }
    }

    public Dimension calcDimension() {
        int x = 100;
        int y = 100;

        Collection<List<Ent2DNode>> coll = Entity2D.E2DCont.getEnt2DValues();

        for (List<Ent2DNode> cc : coll) {
            Dimension dim = getMaxXCoordCol(cc);
            x += dim.width + CONST.XSPACE;
        }

        int len = getMaxColumnSize();
        for (int j = 0; j < len; j++) {
            Dimension dim = getMaxDimRow(j);
            y += dim.height + CONST.XSPACE;
        }

        return new Dimension(x, y);
    }

    public Dimension getLayoutDimension() {
        return layoutDimension;
    }

    public void clearCoord() {
        yCoorH.clear();
        xCoorH.clear();
    }

    /**
     * gibt das Flächengrößte Rechteck einer Spalt zurück
     *
     * @param col : Reihe
     * @return Flächengrösstes Rechteck
     */

    public Dimension getMaxDimRow(int row) {
        int maxW = 0;
        int maxH = 0;
        Collection<List<Ent2DNode>> coll = E2DCont.getEnt2DValues();

        for (List<Ent2DNode> cc : coll) {
            int len = cc.size();
            if (len > row) {
                Ent2DNode co = cc.get(row);
                maxW = Math.max(maxW, co.getRect().width);
                maxH = Math.max(maxH, co.getRect().height);
            }
        }
        return new Dimension(maxW, maxH);
    }

    /**
     * gibt das Flächengrößte Rechteck einer Spalt zurück
     *
     * @param col : Spalte
     * @return Flächengrösstes Rechteck
     */
    public Dimension getMaxXCoordCol(List<Ent2DNode> ht) {
        int maxW = 0;
        int maxH = 0;

        Iterator<Ent2DNode> ecmp = ht.iterator();

        while (ecmp.hasNext()) {
            Ent2DNode co = ecmp.next();
            maxW = Math.max(maxW, co.getRect().width);
            maxH = Math.max(maxH, co.getRect().height);
        }
        return new Dimension(maxW, maxH);
    }

    /**
     * gibt das Flächengrößte Rechteck einer Spalt zurück
     *
     * @param col : Spalte
     * @return Flächengrösstes Rechteck
     */
    public Dimension getMaxDimCol(int col) {
        int maxW = 0;
        int maxH = 0;

        Iterator<Ent2DNode> ecmp = E2DCont.getEnt2NodeIter();

        while (ecmp.hasNext()) {
            Ent2DNode co = ecmp.next();
            maxW = Math.max(maxW, co.getRect().width);
            maxH = Math.max(maxH, co.getRect().height);
        }
        return new Dimension(maxW, maxH);
    }

    /**
     * transforms size of entity(x--y)
     */
    public void preLayoutCircuit() {
        int len = E2DCont.getEnt2DValues().size() - 2;
        System.err.println("#num colums" + len);
        for (int i = len; i > 0; i--) {
            preLayoutColumn(i);
        }
    }

    public void preLayoutColumn(int col) {

        // gets component with maximum width(x-coord)
        Dimension dim = getMaxDimCol(col);
        int xMax = dim.width;

        List<Ent2DNode> ht = E2DCont.getListAt(col);

        if (ht == null)
            return;

        Iterator<Ent2DNode> ecmp = ht.iterator();
        while (ecmp.hasNext()) {
            Ent2DNode co = ecmp.next();
            co.getE2d().transform(xMax, 0);
        }
    }

    public void calcYRowTable() {

        // calc max Y-Direction
        int starty = 100;
        int len = NetListBuilder.getMaxColumnSize() + 1;//getNumberOfRows();
        int yGap = 2 * CONST.YSPACE + CONST.YCELLROW;
        int val = 0;
        for (int j = 1; j <= len; j++) {
            //   System.out.println("==== components overlap "+j+"===");
            // maxO = getCompNodeAtRow(j);
            int lines = rowTable.get(j);
            if (lines == 0) {
                val = yGap;
            } else
                val = (lines + 1) * CONST.LINESPACE + yGap + lines * CONST.LINEWIDTH;

            yCoorH.put(j, new HChannel(j, val, starty, lines));
            //   System.out.println("row_lines: " + j + " " + val + " :: " + lines + " " + starty + " ");
            starty += val;
            layoutDimension.height += val;
        }

        // calculate max X-Direction
        xCoorH.clear();
        starty = 100;
        val = 0;
        len = E2DCont.getNodesize() - 2;
        for (int j = len; j > 0; j--) {
            int lines = columnTable.get(j);
            if (lines == 0) {
                val = yGap;
                // assert(lines > 0);
                //  System.out.println("VChannel 0 lines: " + j);
            }
            int width = getMaxDimCol(j).width;
            if (len != j) {
                if (lines == 0)
                    val = 2 * CONST.XSPACE;
                else
                    val = ((lines + 1) * CONST.LINESPACE) + 2 * CONST.XSPACE + lines * CONST.LINEWIDTH;

                xCoorH.put(j, new VChannel(j, val, starty + val, lines, width));
            } else
                xCoorH.put(j, new VChannel(j, val, starty + val, lines, width));

            //  System.out.println("colum: " + j + " " + val + " " + starty + " " + lines);
            starty += val;
            starty += width;

            layoutDimension.width += val;
            layoutDimension.width += getMaxDimCol(j).width;
        }
    }

    /**
     * Ausgabe der Schaltung in die Datei svg
     *
     * @param svg
     */
    public void layoutCircuit(NetlistWriter svg) {
        resetComponentLayout();
        int len = E2DCont.getNodesize() - 2;

        svg.writeHeader(Integer.toString(layoutDimension.width),
                Integer.toString(layoutDimension.height));

        for (int i = len; i > 0; i--) {
            layoutColumn(svg, i);
        }

        int y = 25;
        for (int i = 1; i < len; i++) {
            String text = Integer.toString(i - 1);
            if (i >= yCoorH.size())
                continue;

            svg.writeText(text, 5, y);
            y = yCoorH.get(i).start + 1;
        }
    }

    public void layoutColumn(NetlistWriter svg, int col) {

        int mod = Math.floorMod(col, 2);

        boolean equ = mod == 0;

        Dimension dim = getMaxDimCol(col);
        List<Ent2DNode> ht = E2DCont.getListAt(col);

        if (col <= E2DCont.getNodesize() - 2 && col >= 1) {
            xcoor = xCoorH.get(col).start;
        }

        Iterator<Ent2DNode> ecmp = ht.iterator();
        while (ecmp.hasNext()) {
            Ent2DNode co = ecmp.next();

            if (co.startRow >= yCoorH.size())
                continue;

            Integer i1 = yCoorH.get(co.startRow).start;
            Integer i2 = yCoorH.get(co.startRow + 1).start;

            if (i1 == null || i2 == null) {
                assert (false);
            }

            if (equ)
                i1 += CONST.LINESPACE / 2;
            //  System.out.println("<| " + co.startRow + " " + i1 + " " + i2 + " |>");

            ycoor = i1;
            //  String s = getName(co.getName());
            //  assert (s != null);
            // co.ycoor = ycoor;
            // co.xcoor = xcoor;
            co.getE2d().transform(xcoor, ycoor);
            //   System.out.println("Channel " + col + "<|| Row" + co.startRow + " " + i1.intValue() + " --> " + i2.intValue() + " |>");


        }
    }

    public void postLayoutCircuit(NetlistWriter svg) {
        resetComponentLayout();
        int len = E2DCont.getNodesize() - 2;
        for (int i = len; i > 0; i--) {
            postLayoutColumn(svg, i);
        }
    }

    public void postLayoutColumn(NetlistWriter svg, int col) {

        // gets component with maximum width(x-coord)
        int xcoorTmp = 0;
        int mod = Math.floorMod(col, 2);

        boolean equ = mod == 0;

        Dimension dim = getMaxDimCol(col);
        List<Ent2DNode> ht = E2DCont.getListAt(col);

        int xdiff = (int) ((dim.width + 10) / 2);

        String text = Integer.toString(col);


        if (col <= E2DCont.getNodesize() - 2 && col >= 1) {
            xcoor = xCoorH.get(col).start;
            if (col > 1)
                xcoorTmp = xCoorH.get(col - 1).width;
        }

        Iterator<Ent2DNode> ecmp = ht.iterator();
        while (ecmp.hasNext()) {
            Ent2DNode co = ecmp.next();

            if (co.startRow >= yCoorH.size())
                continue;

            Integer i1 = yCoorH.get(co.startRow).start;
            Integer i2 = yCoorH.get(co.startRow + 1).start;


            if (i1 == null || i2 == null) {
                assert (false);
            }

            if (equ)
                i1 += CONST.LINESPACE / 2;
            //  System.out.println("<| " + co.startRow + " " + i1 + " " + i2 + " |>");

            ycoor = i1;

            String s = getName(co.getName());
            assert (s != null);
            svg.writeEntity(co.getE2d(), xcoor, ycoor, s, false);
            //   svg.printLine(0, ycoor, layoutDimension.width, ycoor, "green", 2);
            svg.printLine(0, ycoor + CONST.YCELLROW, layoutDimension.width, ycoor + CONST.YCELLROW, "khaki", 2);
            svg.printLine(22, ycoor + CONST.YCELLROW, 22, ycoor + (i2 - i1), "cyan", 6);

            //       System.out.println("Channel "+col+"<| Row" + co.startRow + " " + z + " --> " + i2.intValue() + " |>");
            //     System.out.println(2);
        }// while

        svg.writeText(text, xcoor + xdiff, 25);
        //   svg.printLine(xcoor, 20, xcoor, layoutDimension.height, "blue", 3);
        svg.printLine(xcoor + dim.width, 35, xcoor + xcoorTmp + dim.width, 35, "brown", 3);
        //     svg.printLine(xcoor + dim.width, 20, xcoor + dim.width, layoutDimension.width, "orange", 3);
    }

// graps all possible components  crossed a yCoor-column !

    /**
     * @param from
     * @return gibt die SCC an, in der man die Entity findet
     */
    public int findSCC(String from) {
        return 5;
        /**
         System.out.println(from);
         int idd = Device.getEntity(from).getIdd(); //pg.getNode(from);
         int index = -1;
         for (List<Integer> vs : gr.getSCC()) {
         if (vs.contains(idd)) {
         return ++index;
         }
         index++;
         }
         return index;
         */
    }// findSCC

    /**
     * Input-pins, die nicht in der ersten Spalte sind, müssen in die die ersten
     * Spalte gelegt werden.
     */
    public void assignInputPins() {

        int ll = E2DCont.getNodesize();

        List<Ent2DNode> iList = E2DCont.getListAt(ll - 2);

        int len = iList.get(0).xDist;

        for (int col = 1; col < ll - 2; col++) {

            if (E2DCont.getListAt(col).isEmpty())
                continue;

            ListIterator<Ent2DNode> cmpNode = E2DCont.getListAt(col).listIterator();

            while (cmpNode.hasNext()) {
                Ent2DNode cmp = cmpNode.next();
                if (cmp.getName().compareToIgnoreCase(Device
                        .getTopModuleName()) == 0 || cmp.getName() == "SI")
                    continue;

                Entity e = cmp.getEntity();
                if (e.lpm_type.compareToIgnoreCase("input") == 0) {
                    cmpNode.remove();
                    iList.add(cmp);
                    cmp.xDist = len;
                }
            }
        }
    }

    // -----------------------------------------

    public void printTableList() {
        int ll = E2DCont.getNodesize();
        for (int col = 0; col < ll - 1; col++) {

            if (E2DCont.getListAt(col).isEmpty())
                continue;

            ListIterator<Ent2DNode> cmpNode = E2DCont.getListAt(col).listIterator();
            System.out.print("[ " + col + " ] ");
            while (cmpNode.hasNext()) {
                Ent2DNode cmp = cmpNode.next();
                System.out.print(" " + cmp.getEntity().getCompName());
            }
            System.out.println();
        }
    }// printTableList

    public void setRowCol() {

        int len = E2DCont.getNodesize() - 1;
        int val = 0;
        int[] array = new int[len];
        for (int col = 1; col < len; col++) {
            int startc = 1;
            val = 1;
            List<Ent2DNode> cmpNode1 = E2DCont.getListAt(col);

            for (Ent2DNode cmp : cmpNode1) {
                cmp.startRow = startc;
                cmp.endRow = startc + cmp.spanRow - 1;
                startc = cmp.endRow;
                startc++;

                //    System.out.println(cmp.getName() + " ####~ " + cmp.startRow + " " + cmp.endRow + " " + cmp.spanRow);
                val = cmp.endRow;
                cmp.yDist = cmp.startRow;
            }
            //  System.out.println(col + " #### " + 1 + " >--< " + val);
            array[col] = val;
        }

        int med = Integer.MIN_VALUE;

        for (int j = 1; j < len; j++)
            med = Math.max(array[j], med);

        med = (int) (med / 2);
        //    System.out.println(med);


        for (int col = 1; col < len; col++) {
            int dist = med;
            List<Ent2DNode> cmpNode1 = E2DCont.getListAt(col);
            int prob = 0;
            int di = (int) (array[col] / 2);

            int v = med - di;

            //  System.out.println(med+" "+di+" ~~ "+v+" "+col);

            dist = v;

            for (Ent2DNode cmp : cmpNode1) {
                if (cmp.startRow > med) {
                    prob = 1;
                }
                cmp.startRow += dist + prob;
                cmp.endRow += dist + prob;
                cmp.yDist = cmp.startRow;
                prob = 0;
            }
        }

        Enumeration<Ent2DNode> en = E2DCont.getEnt2NodeEnum();
        while (en.hasMoreElements()) {
            Ent2DNode c = en.nextElement();
            c.getE2d().setPortRow(CONST.YCELLROW, c);
        }
    }

    public void buildRowTable() {
        int len = getMaxColumnSize() + 1;

        Hashtable<Integer, List<Ent2DNode>> crossEntity = E2DCont.getCrossList();

        for (int j = 0; j < len; j++)
            crossEntity.put(j, new ArrayList<>());

        Enumeration<Ent2DNode> en = E2DCont.getEnt2NodeEnum();
        while (en.hasMoreElements()) {
            Ent2DNode c = en.nextElement();
            if (c.startRow != c.endRow) {
                List<Ent2DNode> cm = crossEntity.get(c.endRow);
                cm.add(c);
            }
        }
        System.out.println();
    }

    /**
     * gibt die Spalte einer Entity an
     *
     * @param ent Entity
     * @return Spalten
     */
    public int findColumn(String ent) {
        Ent2DNode cmp = E2DCont.getEnt2DNode(ent);
        assert (cmp != null);
        return cmp.xDist;
    }

    private void reGroupeCompNode(Ent2DNode cmp, int x) {
        List<Ent2DNode> li = E2DCont.getListAt(cmp.xDist);
        int i = li.indexOf(cmp);
        li.remove(cmp);
        cmp.xDist = x;
        li = E2DCont.getListAt(cmp.xDist);
        li.add(cmp);
    }

    /**
     * @param ht
     * @return Komponente mit der größten Y-Ausdehnung
     */


    public void setYCoord() {

        int len = E2DCont.getNodesize();
        int[] colCounter = new int[len];
        int column = 1; // column of output pins
        BFS bbf = new BFS();

        List<Ent2DNode> cmpNode = E2DCont.getListAt(column);
        assert (cmpNode != null);

        ListIterator<Ent2DNode> cp = cmpNode.listIterator();

        while (cp.hasNext()) {

            Ent2DNode cmp = cp.next();

            int val = colCounter[cmp.xDist];
            cmp.yDist = val;
            val++;
            colCounter[cmp.xDist] = val;
            cmp.isPlaced = true;
            ArrayList<ArrayList<Integer>> ar = bbf.bfs(pg, cmp.getEntity().getIdd());
            for (ArrayList<Integer> ai : ar) {
                for (Integer ii : ai) {
                    String name = pg.getNode(ii).getCompName();
                    Ent2DNode cn = E2DCont.getEnt2DNode(name);
                    if (cn.isPlaced)
                        continue;
                    //   System.out.println("XDist:"+cn.xDist+" "+name+" "+len);
                    val = colCounter[cn.xDist];
                    cn.yDist = val;
                    val++;
                    colCounter[cn.xDist] = val;
                    cn.isPlaced = true;
                }
            }
        }// while

        // sorting entitNode in y-Direction

        for (int n = 1; n < len - 1; n++) {
            List<Ent2DNode> cmpNod = E2DCont.getListAt(n);
            if (cmpNod == null)
                continue;
            //    Collections.sort(cmpNod);
        }

        for (int n = 1; n < len - 1; n++) {
            List<Ent2DNode> cmpNod = E2DCont.getListAt(n);
            if (cmpNod == null)
                continue;
            for (int j = 0; j < cmpNod.size(); j++) {
                Ent2DNode cm = cmpNod.get(j);
                cm.yDist = j + 1;
            }
        }

    }

    //----------------------------------------------------------------------

    public void computeSignalLines() {
        int lines = 0;
        java.util.Iterator<List<Ent2DNode>> hhp = E2DCont.getListIterEnt2D();
        while (hhp.hasNext()) {
            List<Ent2DNode> lcp = hhp.next();
            for (Ent2DNode cmp : lcp) {
                int idd = cmp.getEntity().getIdd();
                xml.Entity ent = pg.getNode(idd);
                assert (ent != null);
                // skip top modul
                if (ent.getCompName().equalsIgnoreCase("U463"))
                    System.out.println();
                // skip super nodes
                if (cmp.getName() == "SI" || cmp.getName() == "SO")
                    continue;


                Vector<Port> po = ent.getAllOutPorts();
                for (Port p1 : po) {
                    NetListContainer sigCont = new NetListContainer(cmp.getName(), p1.getPortName(), cmp.getEntity().getIdd());
                    List<PointXY> pinList = Entity2D.getInputPoints(ent, p1.getPortName());
                    sigCont.addPointCloud(pinList);
                }
                lines += po.size();
            }
        }
        System.out.println(" total # of points:" + lines);
    }

    private List<LineXY> adjustVertLines1(NetListContainer net, List<LineXY> cl) {

        List<LineXY> line = new ArrayList<>();
        List<Integer> il = new ArrayList<>();
        List<Integer> ilt = new ArrayList<>();

        for (int j = 1; j < Entity2D.E2DCont.getNodesize(); j++)
            il.add(j);

        for (LineXY li : cl) {
            ilt.add((int) li.x1);
        }

        il.removeAll(ilt);

        for (Integer ii : il) {
            List<PointXY> pinList = net.getInputPinsAt((int) ii);
            if (pinList.isEmpty())
                continue;


            for (PointXY pt : pinList) {
                LineXY ll = new LineXY(pt.getX(), pt.getY(), pt.getX(), pt.getY() - 1);
                ll.copyCoor();
                line.add(ll);
            }

        }
        return line;
    }

    private void adjustVertLines(List<ChannelLine> cl, NetListContainer net) {
        for (ChannelLine cc : cl)
            cc.adjustVertLines(net);
    }

    private ChannelLine getHVChannel(LineXY li) {
        ChannelLine cll = null;
        if (li.isHorizontalLine()) {
            cll = new HorChannelLine(li);
        } else
            cll = new VerChannelLine(li);

        return cll;
    }//if(b1)

    private List<ChannelLine> trans(List<LineXY> li) {
        List<ChannelLine> transList = new ArrayList<>();
        for (LineXY line : li) {
            if (line.isBackEdge()) {
                assert (line.isVerticalLine());
            }
            transList.add(getHVChannel(line));
        }//for
        return transList;
    }

    private List<ChannelLine> transformCoor(NetListContainer net) {

        List<LineXY> hor = LineXY.splitList(net.getSignalPath(), true);
        List<LineXY> ver = LineXY.splitList(net.getSignalPath(), false);

        hor.sort(new LineXY.LineXYVer());
        ver.sort(new LineXY.LineXYHor());

        List<LineXY> horSort = LineXY.mergeHorLines(hor);
        List<LineXY> verSort = LineXY.mergeVerLines(ver);

        List<LineXY> ver1 = adjustVertLines1(net, verSort);
        verSort.addAll(ver1);

        horSort.sort(new LineXY.LineXYVer());
        verSort.sort(new LineXY.LineXYHor());

        LineXY.deleteDoubleLines(verSort);
        LineXY.deleteDoubleLines(horSort);

        List<ChannelLine> transHorLine = trans(horSort);
        List<ChannelLine> transVerLine = trans(verSort);

        transVerLine.addAll(transHorLine);
        adjustVertLines(transVerLine, net);

        return transVerLine;
    }

    private int getFreeLowerRow(int xStart, int xEnd, int row) {

        int r2 = row;

        while (checkRowLine(xStart, xEnd, r2) && r2 > 2) {
            r2--;
        }

        return r2;
    }

    private int getFreeUpperRow(int xStart, int xEnd, int row) {
        while (checkRowLine(xStart, xEnd, row)) {
            row++;
        }
        return row;
    }

    //xStart > xEnd
    private boolean checkRowLine(int xStart, int xEnd, int row) {
        Enumeration<Ent2DNode> en = E2DCont.getEnt2NodeEnum();
        while (en.hasMoreElements()) {
            Ent2DNode dd = en.nextElement();
            if (dd.xDist > xStart || dd.xDist < xEnd)
                continue;
            if (dd.startRow < row && dd.endRow > row) {
                return true;
            }
        }
        return false;
    }

    private List<LineXY> routeSignalPath(NetListContainer netc) {

        List<PointXY> tmpPtList = new ArrayList<>();
        List<LineXY> lineList = new ArrayList<>();

        List<LineXY> containerList = new ArrayList<>();

        ListIterator<PointXY> iter = netc.getPointList().listIterator();

        PointXY pt1 = iter.next();

        tmpPtList.add(pt1);

        int varx = (int) pt1.x;

        while (iter.hasNext()) {
            PointXY pt = iter.next();
            if ((int) pt.x == varx)
                tmpPtList.add(pt);
            else {
                varx = (int) pt.x;
                LineXY line = PointXY.getRowLength(tmpPtList);
                if (tmpPtList.size() > 1)
                    containerList.add(line);
                tmpPtList.clear();
                tmpPtList.add(pt);
                lineList.add(line);
            }
        }//while

        if (!tmpPtList.isEmpty()) {
            LineXY li = PointXY.getRowLength(tmpPtList);
            lineList.add(li);
            if (tmpPtList.size() > 1)
                containerList.add(li);
        }

        ListIterator<LineXY> iterL = lineList.listIterator();

        LineXY l1 = iterL.next();

        if (l1.isPoint()) {

            l1.y2++;
            //     l1.y22++;
        }

        containerList.add(l1);

        while (iterL.hasNext()) {
            // is always vertical column or point
            //  assert(l1.isHorizontalLine());
            LineXY l2 = iterL.next();
            LineXY[] l3 = LineXY.compVerLine(l1, l2);
            l1 = assignLine(l3, l1, l2, containerList);
        }//while

        return containerList;
    }// routeSignal

    /**
     * @param line array of hor and vertical column
     * @param l1   previous column
     * @param l2   next column
     * @return
     */

    private LineXY assignLine(LineXY[] line, LineXY l1, LineXY l2, List<LineXY> contList) {

        int yDist = (int) line[0].y1;
        int row1 = getFreeLowerRow((int) line[0].x2, (int) line[0].x1, yDist);
        int row = getFreeUpperRow((int) line[0].x2, (int) line[0].x1, yDist);
        double z = Math.abs(yDist - row1);
        double z1 = Math.abs(yDist - row);

        if (yDist > 2 && z < z1)
            row = row1;

        if (row == line[0].y1) {
            contList.add(line[0]);

            if (line[1] == null) {
                contList.add(l2);
                return l2;
            } else
                contList.add(line[1]);

            return line[1];
        }

        int vary = getVerLineBound(l1, row);
        int vary_1 = getVerLineBound(l2, row);

        line[0].y1 = row;
        line[0].y2 = row;

        contList.add(line[0]);
        contList.add(l2);

        if (vary > 0) {
            LineXY ll = l1.clone();
            ll.y2 = row;
            ll.x2 = l1.x1;
            contList.add(ll);
        }

        if (vary_1 > 0) {
            assert (l2.isVerticalLine());
            LineXY ll = l2.clone();
            ll.y2 = row;
            contList.add(ll);
            //  return ll;
        }

        if (vary < 0) {
            LineXY ll = l1.clone();
            ll.y1 = row;
            ll.x2 = l1.x1;
            contList.add(ll);
        }

        if (vary_1 < 0) {
            LineXY ll = new LineXY(l2.x2, row, l2.x2, l2.y2);
            contList.add(ll);
            return ll;
        }

        return l2;

    }

    private int getVerLineBound(LineXY line, int y) {
        if (y < line.y1)
            return -1;

        if (y > line.y2)
            return 1;

        return 0;
    }

    private List<ChannelLine> getInterSectChannel(List<ChannelLine> cl, LineXY li) {

        List<ChannelLine> intl = new ArrayList<>();
        for (ChannelLine cc : cl) {
            cc.getInterSectChannel(intl, li);
        }
        return intl;
    }

    private List<LineXY> getCoor(List<ChannelLine> cl, NetListContainer net) {
        List<LineXY> list = new ArrayList<>();
        for (ChannelLine c1 : cl) {
            List<ChannelLine> iList = getInterSectChannel(cl, c1.getLine());

            c1.calculateXYLine(iList, list, net.getEntity(), net.getOutPort(), net.getIdd());
        }

        return list;
    }

    public void computeLineSpace() {

        int ii = NetListBuilder.getMaxColumnSize() + 1;
        for (int j = 1; j <= ii; j++) {
            List<LineXY> li = NetListContainer.getAllLinesAtXY(j, true);
            xml.AIT ai = new xml.AIT(li, true, j);
            rowTable.put(j, (ai.dimMax + 1));

        }
        ii = Entity2D.E2DCont.getNodesize() - 2;
        for (int j = 1; j <= ii; j++) {
            List<LineXY> li = NetListContainer.getAllLinesAtXY(j, false);
            xml.AIT ai = new xml.AIT(li, false, j);
            columnTable.put(j, ai.dimMax + 1);
        }
    }

    //-------------------------------------------------------------------
    private void drawPortPathes(int entity, NetlistWriter svg) {
        xml.Entity ent = pg.getNode(entity);
        if (ent == null) {
            System.out.print(entity);
            assert (0 < 0);
        }

        Vector<Port> vec = ent.getAllOutPorts();

        for (Port p : vec) {
            String s = p.getPortName();
            NetListContainer net = NetListContainer.getNetList(ent.getCompName(), s);
            drawPath(net, svg);
        }
    }

    private void drawPath(NetListContainer net, NetlistWriter svg) {

        NetListContainer sig = NetListContainer.getOutPath(net.getEntity(), net.getOutPort());
        // if (net.getEntity().equalsIgnoreCase("U400"))
        //     System.out.print(9);

        List<ChannelLine> liList = transformCoor(net);

        if (svg == null)
            return;

        List<LineXY> ll = getCoor(liList, net);
        sig.getSignalPath().clear();
        sig.getSignalPath().addAll(ll);
        Collections.sort(sig.getSignalPath(), new LineXY.LineXYHor());
    }

    public void drawSignalPath(NetlistWriter svg) {

        Enumeration<ArrayList<NetListContainer>> eList = NetListContainer.getSigCont().elements();
        while (eList.hasMoreElements()) {
            ArrayList<NetListContainer> al = eList.nextElement();
            for (NetListContainer sig : al) {
                svg.drawSignalPath(sig);
            }
        }
    }

    public void builAllSignalPathes() {

        Enumeration<Ent2DNode> enu = Entity2D.E2DCont.getEnt2NodeEnum();

        while (enu.hasMoreElements()) {
            Ent2DNode cmp = enu.nextElement();
            xml.Entity ent = cmp.getEntity();
            // skip top modul
            //  if (ent.equals(Device.getTopEntity()))
            //    continue;
            // skip super nodes
            if (cmp.getName().equalsIgnoreCase("SI") || cmp.getName().equalsIgnoreCase("SO"))
                continue;

            Vector<Port> po = ent.getAllOutPorts();
            if (cmp.getName().equalsIgnoreCase("U463"))
                System.out.println();
            for (Port p1 : po) {
                NetListContainer sig = NetListContainer.getOutPath(ent.getCompName(), p1.getPortName());
                Entity2D e2d1 = cmp.getE2d();
                Entity2D.Port2D p2d1 = e2d1.getPort(p1.getPortName());
                sig.getPointList().sort(new PointXY());
                List<LineXY> lilli = routeSignalPath(sig);
                lilli.sort(new LineXY.LineXYVer());
                sig.checkSignalPath(lilli, p2d1);
                sig.getSignalPath().addAll(lilli);
            }
        }
    }

    public void reComputeLineSpace() {
        rowTable.clear();
        columnTable.clear();
        int[] ver = VChannel.getFreeHChannels();
        int[] hor = HChannel.getFreeHChannels();


        for (int j = 1; j < ver.length; j++) {
            columnTable.put(j, ver[j]);
        }

        for (int j = 1; j < hor.length; j++) {
            rowTable.put(j, hor[j]);
        }
        clearCoord();
        Entity2D.E2DCont.getCrossList().clear();
        getLayoutDimension().setSize(0, 0);
        HChannel.reset();
        VChannel.reset();
        calcYRowTable();
    }

    public void drawAllPreviewPathes(NetlistWriter svg) {

        Hashtable<Integer, Entity> hl = pg.getVertics();
        Enumeration<Entity> ens = hl.elements();

        while (ens.hasMoreElements()) {
            Entity ent = ens.nextElement();
            //      System.out.println("draw pathes for entity: " + ent.getCompName());
            if (ent.getCompName() == "SI" || ent.getCompName() == "SO")
                continue;

            drawPortPathes(ent.getIdd(), svg);
        }
    }

    private void checkDisconnectComp(LongestPath lp) {
        final int MAX = Integer.MAX_VALUE - 1;
        System.out.println("check disconnected components");
        Set<Integer> iset = lp.arEl.get(MAX);
        if (iset == null) return;

        for (int i : iset) {
            Entity ee = pg.getVertics().get(i);
            System.out.println(ee.getCompName());
            //  assert (ee.isInputPin() || ee.isOutputPin());
            System.out.println(ee.getCompName());
            pg.getVertics().remove(i);
            gr.removeNode(i);
        }
    }
}// class

