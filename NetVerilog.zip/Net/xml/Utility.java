package xml;

import java.time.Instant;

public class Utility {
    protected static String getTime() {
        Instant tt = Instant.now();
        String s = tt.toString();
        int k = s.indexOf("T");
        return s.substring(0, k);
    }
}
