package xml.geom;

import xml.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Vector;

/**
 * Created by hake on 12/29/18.
 */
public class Port extends DevicePort {

    private Vector<Port> linkOutput = new Vector<>();
    private Vector<Port> linkInput = new Vector<>();

    public Port(String n, Entity e, int dir, boolean b) {
        super(e, n, dir, b);
    }

    public Port(String n, Entity e, int dir) {
        super(e, n, dir, false);
    }


    public void addRefsToBus() { }

    public String getPortDir() {
        if (getDir() < 0)
            return "INPUT";
        else if (getDir() > 0)
            return "OUTPUT";
        else
            return "ZZZ";
    }

    public void addPort(Port p) {
        assert (p != null);
        if (isInputPort()) {
            linkInput.add(p);
        } else {
            linkOutput.add(p);
        }
    }

    public Port clonePort() {

        Port pp = new Port(getPortName(), getEntity(), getDir(), isBus());

        for (Port p : linkInput)
            pp.linkInput.add(p);

        for (Port p : linkOutput)
            pp.linkOutput.add(p);

        return pp;
    }


    public boolean removeAllNotLinkedOutPorts(HashSet<Integer> hi, java.util.Hashtable<String, Entity> htt) {
        Vector<Port> hs = getLinkOutput();
        String from = getEntity().getCompName();
        for (Port po : hs) {
            int idd;
            Entity ee = po.getEntity();
            System.out.println(ee.getCompName());

            if (Device.getTopEntity()==ee)
                idd = htt.get(po.getPortName()).getIdd();
            else
                idd = po.getEntity().getIdd();
            if (!hi.contains(idd)) {
                String to = po.getEntity().getCompName();
             //   System.out.println("remove link:" + from + " to " + to + " --> " + po.getEntity().getIdd());
                hs.remove(po);
                return true;
            }
        }
        return false;
    }


    public Port findInputPort(String pname) {
        for (Port p : getLinkInput()) {
            if (p.getPortName().equalsIgnoreCase(pname))
                return p;
        }
        return null;
    }

    public boolean removeLinkedPort(String entity) {

        Vector<Port> v = getLinkOutput();

        for (Port po : v) {
            if (po.getEntity().getCompName().equalsIgnoreCase(entity)) {
                v.remove(po);
                return true;
            }
        }
        return false;
    }


    public Vector<Port> getLinkInput() {
        return linkInput;
    }

    public Vector<Port> getLinkOutput() {
        return linkOutput;
    }


    public void debug() {
        //  System.out.println("==============================================");
        System.out.println("PORT: " + getPortName() + " Entity: "
                + getEntity().getCompName());
        System.out.println(getPortDir() + " Value: " + getDir());
        for (Port po : linkOutput) {
            System.out.println(po.getEntity().getCompName() + " --> " + po.getPortName());
        }
        //  System.out.println("==============================================");
    }

    public ArrayList<Port> getPortList() {
        return null;
    }
}
