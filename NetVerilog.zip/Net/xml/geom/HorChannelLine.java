package xml.geom;

import xml.CONST;

import java.util.List;

import xml.NetListContainer;
import xml.geom.Entity2D.*;
import java.util.function.Function;
import java.util.function.UnaryOperator;
/**
 * Created by hake on 4/8/18.
 */
public class HorChannelLine extends ChannelLine {

    public HorChannelLine() {}

    public HorChannelLine(LineXY li) {
        super(li);
        HChannel hc1 = HChannel.getHChannel((int) li.y1);
        setLineCoor(hc1);
    }

   public void calculateXYLine(List <ChannelLine> iList, List <LineXY> lineList,String ent,String pout,int id) {
        LineXY li = calcXLine(iList, lineList);
        li.set2Coor(li.x1, li.y1, li.x2, li.y2);

        if (li != null)
            lineList.add(li);
    }

    private LineXY calcXLine(List <ChannelLine> iList, List <LineXY> list) {

        int xmin = 0, xmax = 0;
        int len = iList.size();

        boolean recal = false;
        if (len == 1)
            return null;

        int yy = coor;
        int z = 0;
        int XX = (CONST.LINESPACE / 2);
        boolean upper = false;
        boolean isBus=false;
        List <Port2D> portList = Entity2D.getInputPortsAt((int)li.x11);

        for (Port2D pt : portList) {
            int diff = (int) Math.abs(coor - pt.getY());
            if (diff < XX) {
                if(pt.isBus())
                {
                 //   assert(false);
                    pt.toString();
                }
                z = XX - diff;
                upper = coor > pt.getY();
                if (upper) {
                    yy = pt.getY() + XX;
                } else
                    yy = pt.getY() - XX;

                recal = true;
                break;

            }
        }

        if (recal) {

            for (LineXY li : list) {
                if (li.isHorizontalLine())
                    continue;
                if (li.y1 == coor)
                    if (upper)
                        li.y1 += z;
                    else
                        li.y1 -= z;
                if (li.y2 == coor)
                    if (upper)
                        li.y2 += z;
                    else
                        li.y2 -= z;

            }

            coor = yy;
        }// recal


        if (len > 1) {
            xmin = iList.get(0).coor;
            xmax = iList.get(len - 1).coor;
        }

        LineXY l1 = new LineXY(xmin, yy, xmax, yy);
        l1.set2Coor(li.x1, li.y1, li.x2, li.y2);
        return l1;
    }

    public void adjustVertLines(NetListContainer sig){}

}
