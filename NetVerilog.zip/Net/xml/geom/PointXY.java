package xml.geom;

import java.awt.geom.Point2D;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.*;
import java.lang.Double;

public class PointXY extends Point2D.Double implements java.util.Comparator <PointXY> {

    private static final long serialVersionUID = 1528159364550629188L;

    public String pin = null;
    public String entity = null;
    public int idd=-1;


    public PointXY() {
        super(0, 0);
     }

    public PointXY(double arg0, double arg1) {
        super(arg0, arg1);
        assert(arg0 >= 0.0D);

    }

    public PointXY(double arg0, double arg1, String ent, String pin) {
        super(arg0, arg1);
        assert(arg0 >= 0.0D);

        this.pin = pin;
        this.entity=ent;
    }



    public String toString() {
        return super.toString();
    }

    public void printPoint() {
        if (entity == null) {
            entity = "InterPoint";
            pin = "IP";
        }
        System.out.println(entity + " " + pin + ":[x--coor " + x + " ][y--coor " + y + " ]");
    }


    public boolean equals(PointXY pxy) {
        return super.equals(pxy);
    }

    public int compare(PointXY p1, PointXY p2) {
        if (p1.x < p2.x)
            return 1;
        else if (p1.x == p2.x)
            return 0;
        else
            return -1;
    }


    public void setIdd(int idd) {
        this.idd = idd;
    }

    public static LineXY getRowLength(java.util.List <PointXY> li) {

        double x=0.0;
        double max = 0.0;
        double min = Integer.MAX_VALUE;

        assert (!li.isEmpty());


        Optional<PointXY> maxi =  li.stream().max((a,b)->java.lang.Double.compare(a.y,b.y));
        Optional<PointXY> mini =  li.stream().min((a,b)->java.lang.Double.compare(a.y,b.y));

         double max1=maxi.get().y;
         double min1=mini.get().y;
         double x1=maxi.get().x;

         for (PointXY pt : li) {
            x = pt.x;
            max = Math.max(max, pt.y);
            min = Math.min(min, pt.y);
        }

        assert(max==max1);
        assert(min==min1);
        assert(x==x1);

        return new LineXY(x1, min1, x1, max1);
    }

}
