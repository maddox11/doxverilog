package xml.geom;

import xml.CONST;
import xml.Device;
import xml.Entity;

import java.util.*;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.*;
import java.util.List;

import xml.graph.PartGraph;

public class Entity2D {

    private final static int SEP = 20;

    /**
     * default Font ARIAL PLAIN 14
     */

    final static Font font = new Font("Arial", Font.PLAIN, 14);
    final static FontRenderContext frc = new FontRenderContext(
            new AffineTransform(), true, true);
    /**
     * mindestbreite pro Entity
     */
    final static int MINWIDTH = 50;
    /**
     * mindesthöhe pro Entity
     */
    final static int MINHEIGHT = 50;
    // special
    private Entity node;
    /**
     * soll das Rechteck gezeichnet werden ?
     */

    public Hashtable <String, Port2D> inP = new Hashtable <>();
    public Hashtable <String, Port2D> outP = new Hashtable <>();

    /**
     * maximale Länge der Output ports
     */
    public int maxOL = 0;

    /**
     * maximal länge der Input Ports
     */

    public int maxIL = 0;

    /**
     * oberer linker 2D Point rectOuter
     */

    private Point ptUpperLeft;

    /**
     * rectOuter : Rechteck inclusive Beschriftung INPUT-OUTPUT Ports rectInner
     * : Rechteck ohne Beschriftung etc.
     */

    private Rectangle rectOuter, rectInner;

    public Entity2D(Entity eNode) {
        this(eNode, 0, 0);
    }

    public Entity2D(Entity eNode, int x, int y) {
        node = eNode;
        ptUpperLeft = new Point(x, y);
        computeDimension(node, false);

    }

    public Hashtable <String, Port2D> getOutPorts() {
        return outP;
    }

    public Hashtable <String, Port2D> getInPorts() {

        return inP;
    }

    public Port2D getPort(String port) {
        Port2D p2 = inP.get(port);

        if (p2 != null)
            return p2;

        Enumeration <Port2D> en = inP.elements();
        while (en.hasMoreElements()) {
            Port2D pp = en.nextElement();
            if (!pp.isBus())
                continue;
            else {
                if (pp.bus.contains(port)) {
                    p2 = inP.get(pp.getPortName());
                    if (p2 != null)
                        return p2;
                }
            }
        }

        if (p2 != null)
            return p2;

        return outP.get(port);
    }

    public void resetLayout() {
        //System.out.println(this.node.compName+" ~~~~");
        ptUpperLeft.setLocation(0, 0);
        rectInner.setLocation(0, 0);
        Enumeration <Port2D> col = inP.elements();
        while (col.hasMoreElements()) {
            Port2D p2 = col.nextElement();
            Rectangle rec = p2.rec;
            rec.setLocation(0, 0);
        }

        col = outP.elements();
        while (col.hasMoreElements()) {
            Port2D p2 = col.nextElement();
            Rectangle rec = p2.rec;
            rec.setLocation(0, 0);
        }

        computeDimension(this.node, true);
        Rectangle lp = getStringRect(node.getCompName());
        if (maxIL > 0)
            this.transform(maxIL, lp.height);

    }

    /**
     * berechnet die Abmessungen der Entity mit all iheren IO-Pins+Bezeichnung
     *
     * @param ee Entity
     */
    public void computeDimension(Entity ee, boolean reset) {
        Rectangle lp = getStringRect(ee.getCompName());
        int inPorts = ee.getAllInputPorts().size();
        int outPorts = ee.getAllOutPorts().size();
        int max = Math.max(inPorts, outPorts);
        int heigh = (max + 1) * SEP;
        int minW = (int) Math.max(lp.getWidth(), MINWIDTH);

        rectInner = new Rectangle(minW, heigh);

        int i = 1;
        int y1 = (int) rectInner.getY();

        for (Port p : ee.getAllInputPorts()) {
            int x1 = (int) rectInner.getX();
            Port2D port = new Port2D(ee, p.getPortName(), p.getDir(), p.isBus());
            if (p.isBus())
                port.addBus( p.getPortList());
            if (reset) {
                Port2D xx = getPort(p.getPortName());
                port.line = xx.line;
                port.column = xx.column;
            }
            Rectangle r = new Rectangle(getStringRect(p.getPortName()));
            port.rec = r;
            port.p1 = new Point(x1, i * SEP + y1);
            inP.put(p.getPortName(), port);
            maxIL = (int) Math.max(maxIL, r.getWidth());
            i++;
        }

        Enumeration <Port2D> enode = inP.elements();
        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            po.p1.translate(-maxIL, 0);
        }

        i = 1;
        for (Port p : ee.getAllOutPorts()) {
            int x1 = (int) rectInner.getX() + (int) rectInner.getWidth();
            Port2D port = new Port2D(ee, p.getPortName(), p.getDir(), p.isBus());
            if (p.isBus())
                port.addBus(p.getPortList());
            if (reset) {
                Port2D xx = getPort(p.getPortName());
                port.line = xx.line;
                port.column = xx.column;
            }
            Rectangle r = new Rectangle(getStringRect(p.getPortName()));
            port.rec = r;
            port.p1 = new Point(x1, i * SEP + y1);
            outP.put(p.getPortName(), port);
            maxOL = (int) Math.max(maxOL, r.getWidth());
            i++;
        }

        enode = outP.elements();
        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            po.p1.translate(maxOL, 0);
        }

        int maxW = (int) Math.max(MINWIDTH, lp.getWidth()) + 1;
        int maxH = Math.max(MINHEIGHT, heigh);
        int totalWidth = maxW + maxIL + maxOL;
        int totalHeight = (int) (maxH + lp.getHeight()) + 1;
        rectOuter = new Rectangle(totalWidth, totalHeight);
        ptUpperLeft.setLocation(rectOuter.getX(), rectOuter.getY());
    }

    /**
     * Berechnet die benötigte Fläche des Strings str
     *
     * @param str zu berechnender String
     * @return Rechteck
     */
    private Rectangle getStringRect(String str) {
        GlyphVector gvec = font.createGlyphVector(frc, str);
        Rectangle r = gvec.getPixelBounds(frc, 0, 0);
        r.grow(4, 1);
        return r;
    }

    /**
     * @return Rechteck mit IO-Pins
     */
    public Rectangle getOuterRect() {
        return rectOuter;
    }

    /**
     * @return Rechteck ohne IO-Pins
     */
    public Rectangle getInnerRect() {
        return rectInner;
    }

    public int getWidth() {
        return rectOuter.width;
    }

    public int getHeight() {
        return rectOuter.height;
    }

    /**
     * transformiert dass Rechteck nach x-y-coor
     *
     * @param x -coor
     * @param y -coor
     */
    public void transform(int x, int y) {
        int z = (int) getStringRect(node.getCompName()).getY();
        rectOuter.translate(x - maxIL, y + z);
        ptUpperLeft.setLocation(rectOuter.getX(), rectOuter.getY());
        rectInner.translate(x, y);

        Enumeration <Port2D> enode = inP.elements();
        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            po.p1.translate(x, y);
        }

        enode = outP.elements();

        while (enode.hasMoreElements()) {
            Port2D po = enode.nextElement();
            po.p1.translate(x, y);
        }

    }// transform


    public static List <PointXY> getInputPoints(Entity entity, String port) {
        ArrayList <PointXY> li = new ArrayList <>();
        Port p = entity.getPort(port);
        Ent2DNode cm = E2DCont.getEnt2DNode(p.getEntity().getCompName());
        //   Ent2DNode cm1 = cmpAll.get("txcirq");
        Entity2D e2d1 = cm.e2d;
        Port2D p2d1 = e2d1.getPort(p.getPortName());
        PointXY at1 = new PointXY(p2d1.column, p2d1.line, e2d1.getEntity().getCompName(),
                p2d1.getPortName());
        at1.setIdd(e2d1.getEntity().getIdd());
        li.add(at1);

        if (p.getLinkOutput() == null)
            return li;

        for (Port po : p.getLinkOutput()) {
           // System.out.println("->:"+po.getEntity().getCompName());
           // if(po.getEntity().getCompName().equalsIgnoreCase("U373_Result"))
           //     System.out.println();
            Ent2DNode cmp = E2DCont.getEnt2DNode(po.getEntity().getCompName());
            if (po.getEntity().getCompName().equalsIgnoreCase(Device.getTopModuleName())) {

                cmp = E2DCont.getEnt2DNode(po.getPortName());
            }
            if(cmp==null) {
                System.out.println("...."+cmp.getEntity().getCompName());
            }
            assert (cmp != null);
            Entity2D e2d = cmp.e2d;

            Port2D p2d = e2d.getPort(po.getPortName());

            if (p2d.p1.x < 0 || p2d.p1.y < 0) {
                System.out.println(e2d.getEntity().getCompName() + "$$" + po.getPortName());
                System.exit(2);
                continue;
            }

            PointXY at = new PointXY(p2d.column, p2d.line, e2d.getEntity().getCompName(),
                    p2d.getPortName());
            at.setIdd(e2d.getEntity().getIdd());
            li.add(at);
        }
        return li;
    }

    public static List <Port2D> getInputPortsAt(int column) {
        List <Port2D> plo = new ArrayList <>();
        List <Ent2DNode> cpL = E2DCont.getListAt(column);
        for (Ent2DNode cmp : cpL) {
            Collection <Port2D> co1 = cmp.e2d.inP.values();
            for (Port2D pp : co1) {
                plo.add(pp);
            }
        }
        return plo;
    }


    public void setPortRow(int cellHeigh, Ent2DNode cmp) {

        if (cmp.getName().equalsIgnoreCase("z_FFd1_In2"))
            System.out.print(3);

        Hashtable <String, Port2D> table = new Hashtable <>();
        table.putAll(inP);
        table.putAll(outP);

        Enumeration <Port2D> en = table.elements();
        while (en.hasMoreElements()) {
            Port2D p2D = en.nextElement();
            int row = 0;
            double hu = p2D.p1.y + (rectOuter.height - rectInner.height) + 2;
            double hw = cellHeigh;
            double val = hu / hw;
            row = (int) Math.ceil(val);
            p2D.setChannel(cmp, row);
        }
    }

    public Entity getEntity() {
        return node;
    }

    public static Entity2D getEntityD(String e2d) {
        Ent2DNode com = E2DCont.getEnt2DNode(e2d);
        return com.e2d;
    }

    public static java.awt.Point getPortXY(int entIDD, String p) {
        PartGraph pg= Device.getPartGraph();
        Entity ee=pg.getNode(entIDD);
        return getEntityD(ee.getCompName()).getPort(p).getPointXY();
    }

    public Ent2DNode createEnt2DNode(int i) {
        Ent2DNode cm = new Ent2DNode(this, i);
        return cm;
    }

    public List <PointXY> getInputBusesPoints() {
        ArrayList <PointXY> pi = new ArrayList <>();
        for (Port2D p2d : inP.values()) {
            if (p2d.isBus())
                pi.add(new PointXY(p2d.p1.x, p2d.p1.y));
        }
        return pi;
    }

    public final class Ent2DNode implements Comparable <Ent2DNode> {

        public int xDist;

        // line
        public int yDist;

        // rectangle coordinations after computation
        // public int xcoor, ycoor;

        // first line of entity appearance
        public int startRow = 0;

        // last line of entity appearance
        public int endRow = 0;

        // number of input ports
        public int inputPort = 0;

        /**
         * anzahl der Reihen, die von der komponente beansprucht wird
         */
        public int spanRow = 0;

        public double bubbleValue=0.0;

        public String getName() {
            return node.getCompName();
        }

        public Rectangle getRect() {
            return rectOuter;
        }

        public Entity getEntity() {
            return node;
        }

        /**
         * anzahl der Reihen, die von allen eingehen Komponenten beansprucht
         * wird
         */

        public boolean isPlaced = false;

        private Entity2D e2d = null;

        public Ent2DNode() { }

        public Ent2DNode(Entity2D e2d, int i) {
            xDist = i;
            this.e2d = e2d;
            inputPort = e2d.getInPorts().size();
            spanRow = (int) Math.ceil((e2d.getOuterRect().height + 2) / (CONST.YCELLROW * 1.0));

        }

        public final Entity2D getE2d() {
            return e2d;
        }

        public int compareTo(Ent2DNode arg0) {

            if (arg0.bubbleValue == bubbleValue)
                return 0;// assert (false);
            if (arg0.bubbleValue < bubbleValue)
                return -1;

            return 1;
        }
    }

    public static class E2DCont {

        /**
         * enthält die Komponenten die über eine Spalte hinausragen
         */
        private static Hashtable <Integer, List <Ent2DNode>> crossEntity = new Hashtable <>();

        private static Hashtable <String, Ent2DNode> cmpAll = new Hashtable <>();
        /**
         * enthält die Komponenten für jede Spalte (Matrix)
         */
        private static Hashtable <Integer, List <Ent2DNode>> entNode = new Hashtable <>();

        public static void addEnt2DNodeList(List <Ent2DNode> e, int index) {
            entNode.put(index, e);
        }

        public static Hashtable <Integer, List <Ent2DNode>> getCrossList() {
            return crossEntity;
        }

        public static void addEnt2DNode(Ent2DNode e, String name) {
            cmpAll.put(name, e);
        }

        public static Iterator <List <Ent2DNode>> getListIterEnt2D() {
            Collection <List <Ent2DNode>> col = entNode.values();
            return col.iterator();
        }

        public static List <Ent2DNode> getListAt(int index) {
            return entNode.get(index);

        }


        public static int getNodesize() {
            return entNode.size();

        }

        public static Collection <List <Ent2DNode>> getEnt2DValues() {
            return entNode.values();
        }

        public static Ent2DNode getEnt2DNode(String name) {
            return cmpAll.get(name);
        }

        public static Iterator <Ent2DNode> getEnt2NodeIter() {
            Collection <Ent2DNode> col = cmpAll.values();

            return col.iterator();
        }

        public static Enumeration <Ent2DNode> getEnt2NodeEnum() {

            return cmpAll.elements();
        }

        public static Enumeration <List <Ent2DNode>> getListEnumEnt2D() {
            return entNode.elements();
        }

        public static void reset() {
            cmpAll.clear();
            entNode.clear();
            crossEntity.clear();
        }
    }

    /**
     * speichert die Abmessungen und Koordinaten des Rechtecks
     *
     * @author hake
     */
    public static final class Port2D extends DevicePort {

        private Point p1;
        public Rectangle rec;
        public Vector <String> bus = null;
        public int line = 0;
        public int column = 0;

        public Port2D(Entity e, String n, int dir, boolean bus) {
            super(e, n, dir, bus);
        }


        public void addBus(ArrayList <Port> li) {
            if (li.isEmpty())
                return;
            bus = new Vector <>();
            setBus(true);
            for (Port p : li) {
                bus.add(p.getPortName());
            }
        }

        public Point getPointXY() {
            return p1;
        }

        public int getX() {
            return p1.x;
        }

        public int getY() {
            return p1.y;
        }

        @Override
        public String toString() {
            StringBuffer str = new StringBuffer();
            str.append(getPortName() + " ");
            String s = "[ line " + line + " ][ column " + column + "] [Point " + p1.x + " " + p1.y + "]";
            str.append(s);
            return str.toString();
        }


        public void setChannel(Ent2DNode cmp, int row) {
            this.line = row + cmp.startRow - 1;
            if (isInputPort())
                column = cmp.xDist;
            else
                column = cmp.xDist - 1;

             assert (column >= 0);

        }
    }
}
