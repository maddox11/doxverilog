package xml.geom;


import java.util.List;

import xml.Device;

public class Edge  implements Comparable<Edge> {

	public final static int BACKEDGE = 2;
	public int u, v;
	public int edgeType = 0;

	public Edge(){}

	public Edge(int a, int b) {
		u = a;
		v = b;
	}

	public void printEdge() {
		System.out.println("Edge:" + Device.getCompName(u) + "-~->"
				+ Device.getCompName(v));
	}

	public Edge cloneEdge(){
		Edge ee=new Edge(u,v);
		ee.edgeType=this.edgeType;
		return ee;
	}

	public static void printEdge(List<Edge> elist){
		elist.forEach(Edge::printEdge);
	}

	public static void printEdge(java.util.HashSet<Edge> elist){
		//java.util.ArrayList<Edge>ee=new ArrayList<>(elist);
		//Collections.sort(ee);
		//for(Edge eg:ee)
		//	eg.printEdge();

		elist.stream().sorted(Edge::compareTo).forEach(Edge::printEdge);
	}

	public boolean equal(Edge e) {
		return (u == e.u) && (v == e.v);
	}

	public static void printEdge(int u, int v) {
		System.out.println("Edge:" + Device.getCompName(u) + "-..->"
				+ Device.getCompName(v));
	}

	public int compareTo(Edge arg0) {

		String s1=Device.getEntity(arg0.u).getCompName();
		String s2=Device.getEntity(u).getCompName();

		return s1.compareTo(s2);
	}

}
