package xml.geom;

import java.util.Hashtable;
import java.util.Iterator;
import xml.CONST;

/**
 * Created by hake on 11/26/17.
 */
public class HChannel extends Channel {

    private static Hashtable<Integer, HChannel> xHChannel = new Hashtable <Integer, HChannel>();

    public HChannel(int i, int w, int s, int l) {
        chan = i;
        width = w;
        start = s;
        lines = l;

        int starty = s;
        starty += CONST.XSPACE + CONST.YCELLROW ;

        for (int j = 1; j <= l; j++) {
            Channel c = new Channel(1, starty, true);
             starty += CONST.LINESPACE +CONST.LINEWIDTH;
            listChan.add(c);
        }

        xHChannel.put(i,this);
    }

    public static HChannel getHChannel(int i)
    {
        return xHChannel.get(i);
    }


    public static void reset(){ xHChannel.clear();}

    public static int  getFreeHChannel(int i)
    {
     HChannel hc=getHChannel(i);
     return hc.getFreeChannel();
    }

    public static int[]  getFreeHChannels()
    {
        int free=0;
        java.util.Collection<HChannel> cc=xHChannel.values();
        Iterator<HChannel> iter=cc.iterator();
        int len=cc.size();
        int [] val=new int[len+1];
        while(iter.hasNext())
        {
            HChannel v=iter.next();
            int num=v.getFreeChannel();
            free+=num;
            int k=v.listChan.size();
            val[v.chan]=k-num;
      //      System.out.println("Hor "+v.chan+" has free channels "+num+" #channels:"+k);
        }
    //    System.out.println("total free HChannels: "+free);
        return val;
    }

} // HChannel
