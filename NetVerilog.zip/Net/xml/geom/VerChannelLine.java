package xml.geom;

import xml.Device;
import xml.NetListBuilder;
import java.util.*;
import xml.NetListContainer;
import xml.graph.PartGraph;


/**
 * Created by hake on 4/8/18.
 */
public class VerChannelLine extends ChannelLine {

    // min max value for each port in a line
    private int ymin = 0;
    private int ymax = 0;

    java.util.List<PointXY> ptList = new java.util.ArrayList<>();

    public VerChannelLine() {
    }

    public VerChannelLine(LineXY li) {
        super(li);
        VChannel vc1 = VChannel.getVChannel((int) li.x1);
        setLineCoor(vc1);
    }

    public void calculateXYLine(List<ChannelLine> iList, List<LineXY> lineList, String ent, String port, int id) {
        lineList.add(calcYLine(iList));
        assert (ptList.size() > 0);

        if (ent.equalsIgnoreCase("U56")) {
            System.out.println();
        }

        PartGraph pg = Device.getPartGraph();

        Port qp = pg.getNode(id).getPort(port);

        boolean hh = qp.isBus();
        for (PointXY pt : ptList) {
            Entity2D ee2 = Entity2D.getEntityD(pt.entity);
            Entity2D.Port2D po = ee2.getPort(pt.pin);
            Port poo = ee2.getEntity().getPort(pt.pin);
            java.awt.Point pto = po.getPointXY();
            boolean bbu = port.equalsIgnoreCase(po.getPortName());
            PointXY poi = new PointXY(coor, pto.y);
            poi.pin = poo.getPortName();
            poi.entity = poo.getEntity().getCompName();
            LineXY li = new LineXY(coor, pto.y, pto.x, pto.y);
            if (hh || po.isBus())
                li.setLineAttr(lineList, poi, po, bbu, hh);

            lineList.add(li);
        }
    }

    private LineXY calcYLine(List<ChannelLine> iList) {
        int ymin1, ymax1 = 0;

        int len = iList.size();

        assert (len <= 2);

        if (len == 0) {
            ymin1 = ymin;
            ymax1 = ymax;
        } else if (len == 1) {
            ymax1 = iList.get(0).coor;
            ymin1 = ymax1;
        } else {
            ymin1 = iList.get(1).coor;
            ymax1 = iList.get(0).coor;
        }

        int y1 = Math.min(ymin, ymin1);
        int y2 = Math.max(ymax1, ymax);

        ymin = y1;
        ymax = y2;

        LineXY l1 = new LineXY(coor, y1, coor, y2, li.getStartType(), li.getEndType());
        l1.set2Coor(li.x1, li.y1, li.x2, li.y2);
        return l1;
    }

    public void adjustVertLines(NetListContainer sig) {

        List<PointXY> pinList = sig.getInputPinsAt((int) li.x11);
        if (pinList.isEmpty())
            return;

        ptList.addAll(pinList);
        int[] minMax = NetListBuilder.getMinMaxY(pinList);
        ymin = minMax[0];
        ymax = minMax[1];

    }

}
