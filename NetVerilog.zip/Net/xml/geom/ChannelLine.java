package xml.geom;

import xml.NetListContainer;

import java.util.*;
/**
 * Created by hake on 4/15/18.
 * marker interface for horchannel/verchannel
 */
public class ChannelLine {

    LineXY li = null;
    int coor = 0;

    public ChannelLine() {
    }

    public ChannelLine(LineXY li) {
        this.li = li;
    }

    public void setLineCoor(Channel c1) {
        int x = 0;
        Channel c2 = c1.getChannel(li);

        if (c2 == null)
            x = c1.start;
        else
            x = c2.getCoor();
        coor = x;
    }

    public void getInterSectChannel(List<ChannelLine> liList,LineXY line){

        if (line.equalsLine(li))
            return;
        if (line.intersectsLine(li))
            liList.add(this);

    }

    public void calculateXYLine(List <ChannelLine> iList, List <LineXY> lineList,String ent,String pout,int id)
    {
        assert(false);
    }

    public LineXY getLine(){ return li;}

    public  void adjustVertLines(NetListContainer sig){};

}
