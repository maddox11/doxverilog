package xml.geom;

import java.util.Hashtable;
import java.util.*;
import xml.CONST;

/**
 * Created by hake on 12/2/17.
 */
public class VChannel extends Channel {

    private int colDimWidth;
    private static Hashtable <Integer, VChannel> vChannel = new Hashtable <Integer, VChannel>();

    public VChannel(int i, int w, int s, int l, int colDim) {
        chan = i;
        width = w;
        start = s;
        lines = l;
        colDimWidth = colDim;

         int starty = s - w;
         starty += CONST.XSPACE;

        for (int j = 0; j < lines; j++) {
            Channel c = new Channel(j, starty, false);
            starty += CONST.LINEWIDTH + CONST.LINESPACE;
            listChan.add(c);
        }

        vChannel.put(i, this);
    }

    public static VChannel getVChannel(int i) {
        return vChannel.get(i);
    }

    public static void reset(){ vChannel.clear();}

    public static int[] getFreeHChannels() {
        int free = 0;
        java.util.Collection <VChannel> cc = vChannel.values();
        Iterator <VChannel> iter = cc.iterator();
        int len=cc.size();
        int [] val=new int[len+1];
        while (iter.hasNext()) {
            VChannel v = iter.next();
            int num = v.getFreeChannel();
            free += num;
            int k = v.listChan.size();
            val[v.chan]=k-num;
    //        System.out.println("Ver " + v.chan + " " + k + " has " + num + " free channels" + " " + (k - num));
        }
 //       System.out.println("total free VChannels: " + free);
        return val;
    }

}
