package xml.geom;


import xml.NetListBuilder;

import java.util.*;
import java.util.List;

/**
 * Created by hake on 11/26/17.
 */
public class Channel  {

    public int chan;
    public int start;
    public int width;
    public int lines;

    // store all lines for this column
    public java.util.List <LineXY> lineList = null;

    // all column of column upper class
    public List <Channel> listChan = new ArrayList <Channel>();

    private int coor;

    public Channel() {
        lineList = new ArrayList <>();
    }


    public Channel(int n, int coor, boolean what) {
        chan = n;
        this.coor = coor;
        lineList = new ArrayList <>();
    }


    public Channel getChannel(LineXY li) {

        if (listChan.isEmpty()) {
            return null;
        }

        if (li.isBackEdge()) {
            ListIterator <Channel> liChan = listChan.listIterator(listChan.size());

             while (liChan.hasPrevious()) {
                Channel ch = liChan.previous();
                if (ch.lineList.isEmpty()) {
                    ch.lineList.add(li);
                    return ch;
                }

                // no column may intersect li
               boolean inter = ch.lineList.stream().anyMatch(a->a.intersectsLine(li));


                if (!inter) {
                    ch.lineList.add(li);
                    return ch;
                }
            }

        } else {
            //    assert (!listChan.isEmpty());
            boolean check = false;
            for (Channel ch : listChan) {
                check = checkChannel(li, ch.coor);
                if (ch.lineList.isEmpty()) {
                    if (!check) {
                        ch.lineList.add(li);
                        return ch;
                    }
                }

                // no column may intersect li
               boolean inter = ch.lineList.stream().anyMatch(a->a.intersectsLine(li));

                if (!inter) {
                    if (!check) {
                        ch.lineList.add(li);
                        return ch;
                    }
                }
            }// for
        }
         return null;
    }

    public int getFreeChannel() {
        int free = 0;
        for (Channel chan : listChan) {
            if (chan.lineList.isEmpty())
                free++;
        }

        return free;
    }

    public boolean checkChannel(LineXY li, int coor) {
        if (li.isHorizontalLine()) {
            LineXY line = new LineXY(1, coor, 100000, coor);
            boolean l = NetListBuilder.intersecComp(line, (int) li.y11 + 1, (int) li.x11, (int) li.x22);
            return l;
        }
        return false;
    }


    public int getCoor() {
        return coor;
    }


    public void debug(Channel chan) {
        java.util.Iterator <Channel> hcc = chan.listChan.iterator();
        while (hcc.hasNext()) {

            Channel c1 = hcc.next();
             debug(c1);
        }
    }
}
