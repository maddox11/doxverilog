
package xml.geom;


import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Collectors;

import xml.Constants;
import xml.NetDictionary;
import xml.geom.Entity2D.Port2D;

import javax.sound.sampled.Line;


public class LineXY extends java.awt.geom.Line2D.Double {

    public static final int EDGEPOINT = 1 << 2;
    public static final int ENDPOINT = 1 << 3;
    public static final int CROSSPOINT = 1 << 4;
    public static final int BUSPOINT = 1 << 5;

    private static NetDictionary net = NetDictionary.getInstance();


    //  public int x1, y1, x2, y2;
    public double x11 = 0, y11 = 0, x22 = 0, y22 = 0;

    public boolean isOutport = false;
    public boolean isInPort = false;
    private boolean isBusLine = false;
    private boolean backEdge = false;

    private LineXYPoint pt1 = new LineXYPoint();


    public LineXY() {
        super(0, 0, 0, 0);
    }


    public LineXY(double x01, double y01, double x12, double y12) {

        // we have only vertical or horizontal lines (ortho)
        x1 = x01;
        y1 = y01;
        x2 = x12;
        y2 = y12;
        checkPoints();
        assert (x1 == x2 || y1 == y2);
    }

    public LineXY(double x01, double y01, double x12, double y12, int pStart, int pEnd) {

        // we have only vertical or horizontal lines (ortho)
        x1 = x01;
        y1 = y01;
        x2 = x12;
        y2 = y12;
        checkPoints();
        assert (x1 == x2 || y1 == y2);
        setStartType(pStart);
        setEndType(pEnd);
    }

    public LineXY(PointXY start, PointXY end) {
        x1 = start.x;
        y1 = start.y;
        x2 = end.x;
        y2 = end.y;
        assert (x1 == x2 || y1 == y2);
        checkPoints();

    }


    public static List <LineXY> splitList(java.util.List <LineXY> li, boolean hor) {

        /*
      if(hor)
        return  li.stream().filter((a)->a.isHorizontalLine()).collect(Collectors.toList());

        return  li.stream().filter((a)->a.isVerticalLine()).collect(Collectors.toList());
*/


        List <LineXY> list = new ArrayList<>();

        for (LineXY line : li) {
            LineXY l1 = line.clone();

            if (hor && l1.isHorizontalLine())
                list.add(l1);

            if (!hor && l1.isVerticalLine())
                list.add(l1);

        }
        return list;


    }

    public int setLineAttr(java.util.List <LineXY> li, PointXY pt, Port2D p2d, boolean hh, boolean isbus) {

        isInPort = p2d.isInputPort();
        isOutport = p2d.isOutputPort();

        PointXY pi = getStartPoint();

        String text = null;

        if (p2d.isInputPort()) {
            List <NetDictionary.NetNode> pp1 = net.findOutPort(pt.entity, pt.pin);
            if (!pp1.isEmpty()) {
                NetDictionary.NetNode ki = pp1.get(0);
                text = ki.poEntity + "::" + ki.po;
            }
        }


        for (LineXY line : li) {
            int i = line.containsPoint(pi);
            boolean bh = line.intersectsLine(this);
            if (bh && i == -1) {
                if (p2d.isInputPort()) {
                    if (text != null)
                        setBusNameUp(text);
                    setStartType(CROSSPOINT);
                }
            }

            if (line.isHorizontalLine())
                continue;

            int res = line.containsPoint(pt);
            if (res == 1) {
                if (!(p2d.isBus() && hh)) {
                    line.setArrowUp(Constants.ARROW_Start);
                    if (text != null)
                        line.setBusNameDown(text);
                }
                return res;
            }

            if (res == 2) {
                if (!(p2d.isBus() && hh)) {
                    if (text != null)
                        line.setBusNameDown(text);
                    line.setArrowDown(Constants.ARROW_End);
                }
                return res;
            }
        }
        return 0;
    }


    public static List <LineXY> cloneList(List <LineXY> li) {
            return li.stream().map(l->l.clone()).collect(Collectors.toList());
    }

    public  static  java.util.function.Predicate<LineXY> equ = (li)-> {

       return true;

    };



    public static void deleteLine(java.util.List <LineXY> li, LineXY line) {
        int k=-1;
        for (LineXY ll : li) {
            if (ll.equalsLine(line)) {
                if(++k>0) {
                    li.remove(ll);
                    return;
                }
            }
        }
    }

    public static void deleteDoubleLines(List <LineXY> li) {
        java.util.List <LineXY> clone=LineXY.cloneList(li);
        java.util.ListIterator <LineXY> iter = clone.listIterator();
      //   clone.stream().forEach(a->a.deleteLine1(li,a));

     //   java.util.ListIterator <LineXY> iter = clone.listIterator();

        while (iter.hasNext()) {
            LineXY l = iter.next();
            LineXY.deleteLine(li,l);
        }

    }

    private static void splitList(List <LineXY> tmpList, List <LineXY> lineList) {

        if (tmpList.isEmpty())
            return;

        ListIterator <LineXY> iter = tmpList.listIterator();

        LineXY tmp = tmpList.get(0);

        while (iter.hasNext()) {
            LineXY line = iter.next();
            if (tmp.intersectsLine(line)) {
                if (tmp.isHorizontalLine()) {
                    double xmax = Math.max(line.x2, tmp.x2);
                    double xmin = Math.min(line.x1, tmp.x1);
                    tmp = new LineXY(xmin, line.y1, xmax, line.y1);
                    tmp.copyCoor();
                    tmp.backEdge = line.backEdge;
                } else {
                    double ymax = Math.max(line.y2, tmp.y2);
                    double ymin = Math.min(line.y1, tmp.y1);
                    tmp = new LineXY(line.x1, ymin, line.x1, ymax);
                    tmp.copyCoor();
                    tmp.backEdge = line.backEdge;
                }

            } else {
                lineList.add(tmp);
                tmp = line.clone();
            }
        }// while

        lineList.add(tmp);
    }

    public static List <LineXY> mergeHorLines(List <LineXY> li) {

        List <LineXY> tmpList = new ArrayList <>();
        List <LineXY> lineList = new ArrayList <>();

        if (li.isEmpty())
            return lineList;

        ListIterator <LineXY> iter = li.listIterator();

        while (iter.hasNext()) {
            LineXY line = iter.next();
            if (line.isPoint())
                iter.remove();
        }

        iter = li.listIterator();

        if (!iter.hasNext())
            return lineList;

        LineXY line1 = iter.next();
        tmpList.add(line1);
        double varx = line1.y1;

        while (iter.hasNext()) {
            LineXY line = iter.next();
            if (line.y1 == varx)
                tmpList.add(line);
            else {
                varx = line.y1;
                LineXY.splitList(tmpList, lineList);
                tmpList.clear();
                tmpList.add(line);
            }
        }
        LineXY.splitList(tmpList, lineList);
        return lineList;
    }

    public static List <LineXY> mergeVerLines(List <LineXY> li) {

        List <LineXY> tmpList = new ArrayList <>();
        List <LineXY> lineList = new ArrayList <>();

        ListIterator <LineXY> iter = li.listIterator();


        while (iter.hasNext()) {
            LineXY line = iter.next();
            if (line.isPoint())
                iter.remove();
        }

        iter = li.listIterator();

        if (!iter.hasNext())
            return lineList;

        LineXY line1 = iter.next();
        tmpList.add(line1);
        double varx = line1.x1;

        while (iter.hasNext()) {
            LineXY line = iter.next();
            if (line.x1 == varx)
                tmpList.add(line);
            else {
                varx = line.x1;
                LineXY.splitList(tmpList, lineList);
                tmpList.clear();
                tmpList.add(line);
            }
        }
        LineXY.splitList(tmpList, lineList);
        return lineList;
    }

    public static LineXY[] pointToPoint(PointXY p1, PointXY p2) {
        LineXY[] lxy = new LineXY[3];

        lxy[0] = null; // vertical column
        lxy[1] = null; // horizontal column
        lxy[2] = null; // reserve

        if (p1.y > p2.y) {
            lxy[0] = new LineXY(p1.x, p1.y, p2.x, p1.y);
            lxy[1] = new LineXY(p2.x, p1.y, p2.x, p2.y);
        }

        if (p1.y == p2.y) {
            lxy[0] = new LineXY(p1.x, p1.y, p2.x, p2.y);
        }

        if (p1.y < p2.y) {
            lxy[0] = new LineXY(p1.x, p1.y, p2.x, p1.y);
            lxy[1] = new LineXY(p2.x, p1.y, p2.x, p2.y);
        }

        return lxy;
    }

    public static LineXY[] compVerLine(LineXY l1, LineXY l2) {
        boolean b1 = l1.isPoint();
        boolean b2 = l2.isPoint();

        LineXY[] lxy = new LineXY[3];

        lxy[0] = null; // vertical column
        lxy[1] = null; // horizontal column
        lxy[2] = null; // reserve

        // case 1 point to point
        if (b1 && b2) {
            lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getStartPoint());
        }

        //case 2 column to point
        if (!b1 && b2) {
            if (l1.y1 >= l2.y1) {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getStartPoint());
            } else if (l1.y2 <= l2.y1) {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getStartPoint());
            } else {
                double y = Math.ceil((l1.y2 - l1.y1) / 2.0) + l1.y1;
                PointXY pt = new PointXY(l1.x1, y);
                lxy = LineXY.pointToPoint(pt, l2.getStartPoint());
            }
        }

        //case 3 point to column
        if (b1 && !b2) {
            if (l2.y2 <= l1.y1) {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getEndPoint());
            } else if (l2.y1 >= l1.y1) {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getStartPoint());
            } else {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), new PointXY(l2.x1, l1.y1));
            }
        }

        //case 4 column to column
        if (!b1 && !b2) {
            if (l1.y1 >= l2.y2)
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getEndPoint());
            else if (l1.y2 <= l2.y1) {
                lxy = LineXY.pointToPoint(l1.getStartPoint(), l2.getStartPoint());
            } else if (l1.y1 >= l2.y1 && l1.y2 <= l2.y2) {
                double y = Math.ceil((l1.y2 - l1.y1) / 2.0) + l1.y1;
                PointXY pt1 = new PointXY(l1.x1, y);
                PointXY pt2 = new PointXY(l2.x1, y);
                lxy = LineXY.pointToPoint(pt1, pt2);
            } else if (l1.y1 <= l2.y1 && l1.y2 >= l2.y2) {
                double y = Math.ceil((l2.y2 - l2.y1) / 2.0) + l2.y1;
                PointXY pt1 = new PointXY(l1.x1, y);
                PointXY pt2 = new PointXY(l2.x1, y);
                lxy = LineXY.pointToPoint(pt1, pt2);
            } else if (l1.y1 > l2.y1 && l1.y1 < l2.y2 && l1.y2 > l2.y2) {
                double rr = l2.y2 - l1.y1;
                double cl = Math.ceil(rr);
                double y = Math.ceil((l2.y2 - l1.y1) / 2.0) + l1.y1;
                PointXY pt1 = new PointXY(l1.x1, y);
                PointXY pt2 = new PointXY(l2.x1, y);
                lxy = LineXY.pointToPoint(pt1, pt2);
            } else if (l1.y2 > l2.y1 && l1.y2 < l2.y2 && l1.y1 < l2.y1) {
                double y = Math.ceil((l2.y2 - l2.y2) / 2.0) + l2.y1;
                PointXY pt1 = new PointXY(l1.x1, y);
                PointXY pt2 = new PointXY(l2.x1, y);
                lxy = LineXY.pointToPoint(pt1, pt2);
            }
        }

        assert (lxy[0] != null);
        return lxy;
    }

    public static void assignPoints(List <LineXY> li) {
        List<LineXY> l11= new ArrayList<>();

        for (LineXY line : li) {
            l11.addAll(line.setEndPoints(li));
        }
        li.addAll(l11);
    }

    public boolean intersectPoint(PointXY pt) {
        if (isHorizontalLine() && (pt.y == y1)) {
            return (x1 < pt.x) && (pt.x < x2);
        } else if (isVerticalLine() && (pt.x == x1)) {
            return (y1 < pt.y) && (pt.y < y2);
        }
        return false;
    }

    private List<LineXY> setEndPoints(List <LineXY> li) {
        List<LineXY> l1= new ArrayList<>();
        PointXY p1 = getStartPoint();
        PointXY p2 = getEndPoint();

        boolean b1 = true;
        boolean b2 = true;

        int c1 = 0;
        int c2 = 0;

        boolean bin = isInPort && isBusLine();

        //assert(isInPort==false);

        if (bin)
            assert (isHorizontalLine());

        for (LineXY line : li) {

            if (line.equalsLine(this))
                continue;

            if (line.equalsPoint(p1) && b1) {
                setStartType(EDGEPOINT);
                b1 = false;
            }

            if (line.equalsPoint(p2) && b2) {
                setEndType(EDGEPOINT);
                b2 = false;
            }


            if (line.intersectPoint(p1) && b1) {
                setStartType(CROSSPOINT);
                b1 = false;

            }


            if (line.intersectPoint(p2) && b2) {
                setEndType(CROSSPOINT);
                b2 = false;
            }

            if (line.equalsPoint(p1)) {
                c1++;
            }

            if (line.equalsPoint(p2))
                c2++;

            if(this.intersectsLine(line))
            {
                //   assert(false);
                if(isHorizontalLine() && c1==0 && c2==0)
                {
                    // adding line as cross point
                    LineXY kl=new LineXY(line.x1,y1,line.x1,y1);
                    kl.setCrossPoint(Constants.CROSS_POINT);
                    l1.add(kl);
                }
            }
        }


        if (b1)
            setStartType(ENDPOINT);

        if (b2)
            setEndType(ENDPOINT);


        if (c1 > 1)
            setStartType(EDGEPOINT);

        if (c2 > 1)
            setEndType(EDGEPOINT);

        return l1;
    }

    public boolean equalsLine(LineXY line) {
        return y1 == line.y1 && y2 == line.y2 && x1 == line.x1 && x2 == line.x2;
    }

    public LineXY clone() {

        LineXY clone = new LineXY(getStartPoint(), getEndPoint());
        clone.backEdge = backEdge;
        clone.isBusLine = isBusLine;
        clone.isInPort = isInPort;
        clone.isOutport = isOutport;

         if (this.x11 == 0.0D && this.y11 == 0.0D && this.x22 == 0.0D && this.y22 == 0.0D) {
            clone.x11 = x1;
            clone.x22 = x2;
            clone.y11 = y1;
            clone.y22 = y2;

        } else {
            clone.x11 = x11;
            clone.x22 = x22;
            clone.y11 = y11;
            clone.y22 = y22;
        }
        return clone;
    }

    public void set2Coor(double x1, double y1, double x2, double y2) {
        x11 = x1;
        x22 = x2;
        y11 = y1;
        y22 = y2;
    }

    public void copyCoor() {
        x11 = x1;
        x22 = x2;
        y11 = y1;
        y22 = y2;
    }

    private void checkPoints() {
        assert (x1 >= 0);
        assert (x2 >= 0);
        assert (y1 >= 0);
        assert (y2 >= 0);
        if (isVerticalLine()) {
            //x1==x2
            if (y1 > y2) {
                double tmp = y1;
                y1 = y2;
                y2 = tmp;
            }
        } else {
            // y1==y2
            if (x1 > x2) {
                double tmp = x1;
                x1 = x2;
                x2 = tmp;
            }
        }
    }


    public PointXY getStartPoint() {
        return new PointXY((int) x1, (int) y1);
    }

    public PointXY getEndPoint() {
        return new PointXY((int) x2, (int) y2);
    }

    public boolean isVerticalLine() {
        return x1 == x2;
    }

    public boolean isHorizontalLine() {
        return y1 == y2;
    }

    public boolean isPoint() {
        return x1 == x2 && y1 == y2;
    }

    public boolean equalsPoint(PointXY pt) {
        if (isStartPoint(pt) || isEndPoint(pt))
            return true;

        return false;
    }

    public boolean isStartPoint(PointXY pt) {
        return (pt.x == x1 && pt.y == y1);
    }

    public boolean isEndPoint(PointXY pt) {
        return (pt.x == x2 && pt.y == y2);
    }

    public int containsPoint(PointXY pt) {
        if (isStartPoint(pt))
            return 1;

        if (isEndPoint(pt))
            return 2;

        return -1;
    }

    public boolean intersectsLine(LineXY li) {
        return super.intersectsLine(li);
    }


    private String getPtChar(int id) {
        switch (id) {
            case (ENDPOINT):
                return "ENDPOINT";
            case (CROSSPOINT):
                return "CROSSPOINT";
            case (EDGEPOINT):
                return "EDGEPOINT";
            default:
                return "---";
        }
    }

    public boolean isBusLine() {
        return isBusLine;
    }

    public void setBusLine(boolean busLine) {
        isBusLine = busLine;
    }

    public boolean isBackEdge() {
        return backEdge;
    }

    public void setBackEdge(boolean backEdge) {
        this.backEdge = backEdge;
    }

    //--------------------------------------------------------------
    public Constants getDirection() {
        return pt1.direction;
    }

    public void setDirection(Constants direction) {
        pt1.direction = direction;
    }

    public int getStartType() {
        return pt1.startType;
    }

    public void setStartType(int startType) {
        pt1.startType = startType;
    }

    public int getEndType() {
        return pt1.endType;
    }

    public void setEndType(int endType) {
        pt1.endType = endType;
    }

    public Constants getArrowUP() {
        return pt1.arrowUP;
    }

    public Constants getArrowDOWN() {
        return pt1.arrowDOWN;
    }

    public void setCrossPoint(Constants pt){
        pt1.crossPt=pt;
    }

    public Constants getCrossPoint(){
        return pt1.crossPt;
    }


    public void setArrowUp(Constants arrow) {
        pt1.arrowUP = arrow;
    }

    public void setArrowDown(Constants arrow) {
        pt1.arrowDOWN = arrow;
    }

    public String getBusName1() {
        return pt1.busName;
    }

    public String getBusName2() {
        return pt1.busName1;
    }

    public void setBusNameUp(String busName) {
        pt1.busName = busName;
    }

    public void setBusNameDown(String busName) {
        pt1.busName1 = busName;
    }

    /**
     * Created by hake on 11/5/17.
     */
    public static class LineXYHor extends LineXY implements java.util.Comparator <LineXY> {
        public int compare(LineXY p1, LineXY p2) {
            if (p1.x1 < p2.x1)
                return 1;
            else if (p1.x1 == p2.x1)
                return 0;
            else
                return -1;
        }
    }

    /**
     * Created by hake on 11/5/17.
     */
    public static class LineXYVer extends LineXY implements java.util.Comparator <LineXY> {

        public int compare(LineXY p1, LineXY p2) {
            if (p1.y1 < p2.y1)
                return 1;
            else if (p1.y1 == p2.y1)
                return 0;
            else
                return -1;
        }
    }

    /**
     * Created by hake on 1/14/19.
     */
    private static class LineXYPoint {


        // data[0--7]  [0]...
        String busName = null;

        String busName1 = null;

        // specifies line end/start point
        int startType = 0;

        // specifies line end/start point
        int endType = 0;

        // which edge left/right contains the arrow
        Constants arrowUP = null;

        Constants arrowDOWN = null;

        Constants crossPt = null;
        // which edge left/right contains the arrow
        // Constants arrow = null;

        // UP-RIGHT..  arrow direction
        Constants direction = null;

        public LineXYPoint() {
        }

    }


    @Override
    public String toString() {
        StringBuffer s = new StringBuffer("([" + x1 + " " + y1 + " ],[ " + x2 + " "
                + y2 + "])");

        return s.toString();
    }


    public void printBool() {
        System.out.println("[" + x1 + "," + y1 + "]" + "--> [" + x2 + " " + y2 + "]" + isBusLine + " " + isInPort + " " + isOutport);
    }


    public void printLineCoor() {
        System.out.println("[" + x1 + "," + y1 + "]" + "--> [" + x2 + " " + y2 + "]");
    }


    public void printLineCoor2() {
        System.out.println("[" + x11 + "," + y11 + "]" + "-2-> [" + x22 + " " + y22 + "]");
        printLineCoor();
        System.out.println(getPtChar(getStartType()) + " " + getPtChar(getEndType()));
    }

}// class

