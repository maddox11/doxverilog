package xml.geom;

import xml.Entity;

import java.awt.*;
import java.util.Vector;

/*
 * Created by hake on 1/21/19.
 */
public class DevicePort {

    private String portName;
    private int dir = 0;
    private boolean isBus = false;

    private xml.Entity ent=null;

    public DevicePort(Entity e, String n, int d, boolean b)
    {
        ent=e;
        portName=n;
        dir=d;
        isBus=b;
    }

    public String getPortName() {
        return portName;
    }

    public void setPortName(String portName) {
        this.portName = portName;
    }

    public int getDir() {
        return dir;
    }

    public void setDir(int dir) {
        this.dir = dir;
    }

    public boolean isBus() {
        return isBus;
    }

    public void setBus(boolean bus) {
        isBus = bus;
    }

    public Entity getEntity() {
        return ent;
    }

    public void setEntity(Entity ent) {
        this.ent = ent;
    }

    public boolean isInputPort() {
        return getDir() < 0;
    }

    public boolean isOutputPort() {
        return getDir() > 0;
    }

}
