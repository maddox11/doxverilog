package xml.geom;

import java.util.*;
import java.util.stream.Stream;

import xml.*;

/**
 * Created by hake on 10/6/18.
 */
public class Bus extends Port {

    private ArrayList <Port> portList = new ArrayList <>();

    public Bus(String n, Entity ent, int dir) {
        super(n, ent, dir);
        setBus(true);
    }

    public Bus(String n, Entity ent, int dir, ArrayList <String> al) {
        super(n, ent, dir);
        setBus(true);
          for (String str : al) {
            portList.add(new Port(str, ent, dir));
        }
    }

    public void addRefsToBus() {

        if (getDir() > 0) {
            for (Port po : portList) {
                for (Port pp : po.getLinkOutput()) {
                    getLinkOutput().add(pp);
                }//for
            }
        }
    }// addREF


    public boolean removeLinkedPort(String entity)
    {
        for(Port pp:portList)
        {
            Vector<Port> v=pp.getLinkOutput();
            for(Port po:v)  {
                if(po.getEntity().getCompName().equalsIgnoreCase(entity)) {
                    v.remove(po);
                    if(v.isEmpty())
                        portList.remove(pp);
                    return true;
                }
            }
        }
        return super.removeLinkedPort(entity);
    }



    public Bus clonePort(){
        Bus b = new Bus(getPortName(),getEntity(),getDir());
        b.portList.addAll(portList);

        Vector<Port> lb=b.getLinkOutput();
        lb.addAll(getLinkOutput());

        return b;
    }

    public ArrayList <Port> getPortList() {
        return portList;
    }
}
