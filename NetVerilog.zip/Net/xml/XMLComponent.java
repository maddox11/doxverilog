package xml;


import java.util.*;

class XMLComponent {
    String name;
    String lpm_type = "";

    int lpm_cvalue = -1;
    int lpm_size = -1;
    int lpm_width = -1;

    Vector <String> inPort = new Vector <String>();
    Vector <String> outPort = new Vector <String>();


    public Map <String, ArrayList <String>> inBuses = new TreeMap <>();
    public Map <String, ArrayList <String>> outBuses = new TreeMap <>();


    public XMLComponent() {
    }

    public XMLComponent(String n) {
        name = n;
    }

    public void addInport(String s) {
      //  System.out.println("adding inport  " + s + " to " + name);
        String port=codifyName(s, 1);
        if(port!=null)
        inPort.add(port);
    }

    public void addOutPort(String s) {
      //  System.out.println("adding outport  " + s + " to " + name);
        String port=codifyName(s, 2);
        if(port!=null)
          outPort.add(port);
    }


    private String codifyName(String n, int dir) {

        boolean btop= Device.getTopModuleName().equalsIgnoreCase(name);

        if(btop)
            System.out.println();

        int index = n.indexOf("=");
        if (index > 0)
            n = n.substring(0, index);

        boolean c = n.contains("[");

        if (c) {
            n = n.replace(']', ' ');
            n = n.trim();
            String murks = "\\[";
            String[] val = n.split(murks);
            int port = Integer.parseInt(val[1]);
         //   System.out.println();
            n=val[0];
            ArrayList<String> container=new ArrayList<>();
            for (int j = 0; j < port; j++) {
                String s1 = n + Integer.toString(j);
                container.add(s1);

                if (dir == 2)
                    outPort.add(s1);

                if (dir == 1)
                    inPort.add(s1);
           }

           return null;
/*
            if (dir == 2) {
                outPort.add(container);

                n = n.concat("_#");
                outBuses.put(n,container);
            }
            else {
                n = n.concat("_1");
                inBuses.put(n,container);
            }
            */
        }

        if(btop && c)
            return null;
        return n;
    }


    public void evalBuses() {
        checkInBuses();
        checkOutBuses();
    }

    private void checkOutBuses() {

        Vector <String> data = new Vector <String>();
        final String out1 = "Result";
        final String out2 = "Q";

        boolean bout = false;
        boolean bres = false;

        if (lpm_width <= 1 || outPort.size() <= 1)
            return;


        for (String str : outPort) {

            if (str.startsWith(out1)) {
                bres = true;
                data.add(str);
            }

            if (str.startsWith(out2)) {
                bout = true;
                data.add(str);
            }
        }

        String vec = null;
        if (bres)
            vec = "Result_#";

        if (bout)
            vec = "Q_#";

        for (String str : data)
            assert (outPort.remove(str));

        if (bout || bres) {
            ArrayList <String> al = new ArrayList <>();
            al.addAll(data);
            outBuses.put(vec, al);
        }
    }

    private void checkInBuses() {

        final String inB = "Data";

        if (lpm_width < 1)
            return;

        //   Vector <String> vin1 = new Vector <String>();

        if (lpm_width > 1) {
            HashSet <String> tmp = new HashSet <String>();
            for (String str : inPort) {
                if (str.startsWith(inB)) {
                    String[] res = str.split(inB);
                    tmp.add(res[1]);
                }
            }

            if(tmp.isEmpty())
                return;
            Iterator <String> iter = tmp.iterator();
            boolean more = iter.next().matches("[a-zA-Z]+[0-9]+");
            boolean more1 = iter.next().matches("[0-9]+[x]+[0-9]+");
            boolean more2 = iter.next().matches("[0-9]+");

            HashSet <String> tmp1 = new HashSet <String>();
            for (String str : tmp) {
                if (more) {
                    String val = str.replaceAll("[0-9]", "");
                    tmp1.add(val);
                }

                if (more1) {
                    int index = str.indexOf("x");
                    String val = str.substring(0, index);
                    tmp1.add(val);
                }
            }


            if (more2) {
                ArrayList <String> al = new ArrayList <>();

                for (String str : tmp) {
                    al.add("DATA" + str);
                    assert (inPort.remove("Data" + str));
                }
                inBuses.put("Data_#", al);
            }


            Iterator <String> ii = tmp1.iterator();
            for (int i = 0; i < tmp1.size(); i++) {

                String s = ii.next();
                String vec = "Data_".concat(s);
                ArrayList <String> al = new ArrayList <>();

                for (String str : tmp) {
                    if (more) {
                        if (str.contains(s)) {
                            String sv = "Data" + str;
                            al.add(sv);

                            if (inPort.contains(sv)) {
                                assert (inPort.remove(sv));

                            }
                        }
                    }

                    if (more1) {
                        String s1 = s + "x";
                        if (str.startsWith(s1)) {
                            String k = "Data" + str;
                            al.add(k);
                            boolean del = removePort(k);
                            if (!del) {
                                System.out.println(name + " : " + tmp1.toString() + " " + str);
                                System.out.println(str + " : " + tmp.toString());
                                System.out.println(s1 + " : " + al.toString() + " " + s);

                            }
                            assert (del);
                        }//
                    }
                }
                inBuses.put(vec, al);
            }//for


        }//1.if
    }

    public boolean removePort(String val) {
        int i = 0;
        for (String str : inPort) {
            if (str.equalsIgnoreCase(val)) {
                inPort.remove(i);
                return true;
            }
            i++;
        }
        return false;
    }


    public void debugComponent() {
        System.err.println("XMLComponent portName:" + name);

        System.err.println("LPM_TYPE:" + lpm_type);

        System.err.println("properties (value size widht)->" + lpm_cvalue + " "
                + lpm_size + " " + lpm_width);

        System.err.println("INPUT PORTS");
        // Collections.sort(inPort, new Comparable());
        Iterator <String> iter = inPort.iterator();
        while (iter.hasNext())
            System.err.println(iter.next());

        System.err.println("");
        System.err.println("OUTPUT PORTS");
        // Collections.sort(outPort, new Comparable());
        iter = outPort.iterator();
        while (iter.hasNext())
            System.err.println(iter.next());

    }

}