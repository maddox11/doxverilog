package xml;

import java.io.File;

import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;
import xml.graph.*;
import xml.geom.*;
import xml.graph.PartGraph;

//
public class Device {



    private static Entity checkName(String n) {
        Entity ee = viewRef.get(n);
        if (ee == null) {
            String s = n.substring(1);
            ee = viewRef.get(s);
        }
        return ee;
    }


    private static void addPorts(ArrayList<Node> ports, XMLComponent xmlComp) {
        Iterator<Node> iter = ports.iterator();

        while (iter.hasNext()) {
            Node node = iter.next();
            String portName = getChild(node, "identifier").getTextContent()
                    .replace("\"", " ");
            portName = portName.trim();
            Node reNode = getChild(node, "rename");
            String rename = null;
            if (reNode != null) {
                rename = reNode.getTextContent();
            }
            if (rename != null) {
                portName = rename + "=" + portName;
            }
            Node n = getChild(node, "outputport");
            Node nio = getChild(node, "inoutport");
            if (n != null) {
                xmlComp.addOutPort(portName);
            } else if (nio != null) {
                xmlComp.addOutPort(portName);
            } else
                xmlComp.addInport(portName);

        }
    }


    /**
     * fügt Super Knoten im Graph ein
     */

    private static void createSuperNodes() {
        Entity ee = getTopEntity();

        Vector<Port> io = ee.getAllInputPorts();
        Vector<Port> out = ee.getAllOutPorts();

        for (Port pi : io) {
            if (pi.isBus()) {
                for (Port pp : ((Bus) pi).getPortList()) {
                    int to = viewRef.get(pp.getPortName()).getIdd();
                    graph.addEdge(to, superInput);
                }
            } else {
                int to = viewRef.get(pi.getPortName()).getIdd();
                graph.addEdge(superInput, to);
            }
        }

        for (Port po : out) {
            if (po.isBus()) {
                for (Port pp : ((Bus) po).getPortList()) {
                    int from = viewRef.get(pp.getPortName()).getIdd();
                    graph.addEdge(from, superOutput);
                }
            } else {
                int from = viewRef.get(po.getPortName()).getIdd();
                graph.addEdge(from, superOutput);
            }
        }
    }

    /**
     * erzeuge aus der XMl-Datei die dazugehörigen Entities <view
     * type="U287"><identifier>and2</identifier></view>
     * <identifier>mux1_1_2</identifier></view>
     */
    private static void createEntityReference() {
        //   System.out.println("---");
        viewRef.put(topModule, new Entity(topModule, topModule.toLowerCase()));
        NodeList nodes = doc.getElementsByTagName("view");
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            String val = getAttrib(node, "type");
            String ident = getChild(node, "identifier").getTextContent().trim();
            int k = val.indexOf("|");
            if (k > 0)
                val = val.substring(0, k);

            System.out.println(ident + " .. " + val);
            viewRef.put(val, new Entity(ident, val));
        }
        System.err.println(" adding: " + viewRef.size() + " devices");
    }

    private static void addRefsToBus() {
        Collection<Entity> col = viewRef.values();

        for (Entity en : col) {
            Vector<Port> v = en.getAllInputPorts();
            for (Port p : v)
                p.addRefsToBus();

            v = en.getAllOutPorts();
            for (Port p : v)
                p.addRefsToBus();
        }
    }

    /**
     * jeder Entity wird ihre Eingangs- und Ausgangsports zugewiesen. SI super
     * Eingangsknoten
     * <p>
     * SI---I1 |----I2 |----I3
     * <p>
     * SO super Ausgangsknoten
     * <p>
     * o1--->SO o2 --> | on --> |
     */

    private static void assignEntityReference() {
        Entity ee = getTopEntity();

        Vector<Port> io = ee.getAllInputPorts();
        Vector<Port> out = ee.getAllOutPorts();

        for (Port pi : io) {
             if (pi.isBus()) {
                assert (false); //   e.outPort.addAll(pi.linkOutput);
                Bus b = (Bus) pi;
                for (Port pi1 : b.getPortList()) {
                    Entity e = new Entity(pi1.getPortName());
                    e.lpm_type = "input";
                    e.name = "input";
                    e.addOutPort(pi1.getPortName());
                    viewRef.put(pi1.getPortName(), e);
                }
            } else {
                Entity e = new Entity(pi.getPortName());
                e.lpm_type = "input";
                e.name = "input";
                e.addOutPort(pi.getPortName());
                viewRef.put(pi.getPortName(), e);
            }
        }

        for (Port po : out) {
            if (po.isBus()) {
                assert (false);//   e.outPort.addAll(pi.linkOutput);
                Bus b = (Bus) po;
                for (Port pi1 : b.getPortList()) {
                    Entity e = new Entity(pi1.getPortName());
                    e.lpm_type = "output";
                    e.name = "output";
                    e.addInport(pi1.getPortName());
                    viewRef.put(pi1.getPortName(), e);
                }
            } else {
                Entity e = new Entity(po.getPortName());
                e.lpm_type = "output";
                e.name = "output";
                e.addInport(po.getPortName());
                viewRef.put(po.getPortName(), e);
            }
        }

        // super input
        Entity superO = new Entity("SI");
        viewRef.put("SI", superO);

        // super output
        superO = new Entity("SO");
        viewRef.put("SO", superO);

        Collection<Entity> col = viewRef.values();

        int index = 0;
        for (Entity en : col) {
            entityRef.put(index, en);
            en.setIdd(index);
            // System.err.println("assign device: " + en.getCompName() + " index " + index);
            index++;
        }


        superInput = viewRef.get("SI").getIdd();
        superOutput = viewRef.get("SO").getIdd();
    }

    /**
     * Erzeuge aus der XMl-Datei die Komponenten mit iheren Eingangs und
     * Ausgangsports desweiteren ihren Eigenschaften z. B AND-2 AND-3 usw.
     */

    private static void createEntities() {
        NodeList nodes = doc.getElementsByTagName("component");
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            Node entName = getChild(node, "identifier");
            String eName = entName.getTextContent();
            // System.err.println(entName.getTextContent());
            Node iface = getChild(node, "interface");
            ArrayList<Node> ports = parseXMLTree(iface, "port");
            ArrayList<Node> prop = parseXMLTree(iface, "property");
            XMLComponent ee = new XMLComponent(eName);
            setComponentProperties(prop, ee);
            addPorts(ports, ee);
            ee.evalBuses();
            vecComponent.put(eName, ee);
        }// createEntities
    }

    /**
     * extrahiert die attribute von jeden Knoten <property
     * type="LPM_Width"><identifier>1</identifier> <property
     * type="LPM_Size"><identifier>2</identifier>
     *
     * @param node
     * @param type
     * @return Attribut
     */
    private static String getAttrib(Node node, String type) {
        if (!node.hasAttributes()) {
            return null;
        }

        NamedNodeMap no = node.getAttributes();

        for (int j = 0; j < no.getLength(); j++) {
            Node map = no.item(j);
            if ((map.getNodeName().equalsIgnoreCase(type))) {
                return map.getNodeValue();
            }
        }
        return null;
    }

    private static Node getChild(Node n, String child) {
        NodeList nList = n.getChildNodes();
        int len = nList.getLength();
        for (int j = 0; j < len; j++) {
            Node no = nList.item(j);
            short type = no.getNodeType();
            if (type == Node.ELEMENT_NODE
                    && no.getNodeName().equalsIgnoreCase(child)) {
                return no;
            }
        }
        return null;
    }// printChild

    /**
     * @param entName
     * @return Komponentenvektor
     */

    private static LinkedList<String> spec = new LinkedList<String>();

    public static void parseXMLTree(Node node) {
        NodeList ll = node.getChildNodes();
        for (int i = 0; i < ll.getLength(); i++) {
            Node no = ll.item(i);
            // printNodeType(no.getNodeType());
            if (no.getNodeType() == Node.ELEMENT_NODE) {
                // printAttrib(no);
                boolean portname = no.getNodeName()
                        .equalsIgnoreCase("portname");

                boolean portc = no.getNodeName().equalsIgnoreCase(
                        "portconnection");

                if (portc) {

                    parseConnection1(spec);
                    spec.clear();
                }


                if (portname) {
                    Node lk = no.getParentNode();// .getFirstChild();//.getNodeValue();
                    String s1 = "";
                    Node nl = lk.getFirstChild().getNextSibling();

                    Node mi = no.getFirstChild();


                    if (mi != null) {
                        String n1 = no.getFirstChild().getNodeValue();

                        if (nl.getFirstChild() != null) {
                            s1 = nl.getFirstChild().getNodeValue().trim();
                        }
                        if (s1.isEmpty()) {
                            s1 = topModule;
                        }
                        //    System.out.println(n1 + "--#-" + s1);
                        spec.add(n1 + "-" + s1);
                    }
                }
                parseXMLTree(no);
            }
        }// for
    }

    // add all port permutation
    private static void parseConnection1(LinkedList<String> li) {

        NetDictionary net = NetDictionary.getInstance();
        final int OUTPORT = 1;
        final int ISTOPMODULE = 2;
        Entity e1 = null;
        int index = 0;
        int type = 0;

        if (li.isEmpty()) return;

        String[] lin = li.get(0).split("-");
        e1 = viewRef.get(lin[1]);
        if (e1.getCompName().equalsIgnoreCase("cp2"))
            System.out.println();
        if (e1 == null) {
            lin[1] = lin[1].substring(1);
            e1 = viewRef.get(lin[1]);
        }
        if (e1.getCompName().equals(topModule)) {
            Port p11 = e1.getPort(lin[0]);

            System.out.println(lin[0]);
            if (p11.getDir() > 0) {
                Collections.reverse(li);
            }
        }

        for (String str : li) {
            String[] link = str.split("-");

            e1 = viewRef.get(link[1]);
            if (e1 == null) {
                link[1] = link[1].substring(1);
                e1 = viewRef.get(lin[1]);
                assert (e1 != null);
            }

            Port p1 = e1.getPort(link[0]);

            if (e1.getCompName().equals(topModule)) {
                type = ISTOPMODULE;
                break;
            } else if (p1.isOutputPort()) {
                type = OUTPORT;
                break;
            } else if (p1.isInputPort()) {
                // type = OUTPORT;
                // break;
                Port out = getOutPortFromList(li);
                if (out != null)
                    p1.addPort( out);
            }
            index++;
        }
        /**
         *
         * else if (p1.isInputPort()) { // assert(false); type = INPUTPORT; Port
         * xx = getOutPortFromList(li); // if (xx != null) // p1.addPort(xx); //
         * break; }
         *
         */
        if (type == 0)
            return;

        String tmp = li.remove(index);
        String[] link = tmp.split("-");
        Entity out = checkName(link[1]);
        Port outP = out.getPort(link[0]);

        for (String str : li) {
            String[] linkIn = str.split("-");
            Entity in = viewRef.get(linkIn[1]);
            //  System.out.println(linkIn[1]);

            if (in == null) {
                linkIn[1] = linkIn[1].substring(1);
                in = viewRef.get(linkIn[1]);
            }
            Port pin = in.getPort(linkIn[0]);

            // boolean top1 = out.compName.equals(topModule);
            outP.getLinkOutput().add(pin);

            System.out.println(link[1] + "  " + link[0] + " -|-> " + pin.getEntity().getCompName() + " " + pin.getPortName());
            net.addNetNode(link[1], link[0], pin.getEntity().getCompName(), pin.getPortName());

        }// list iter
    }

    private static Port getOutPortFromList(LinkedList<String> li) {
        Port oo = null;
        for (String ss : li) {
            String[] link = ss.split("-");
            Entity e1 = viewRef.get(link[1]);
            if (e1 == null) {
                link[1] = link[1].substring(1);
                e1 = viewRef.get(link[1]);
            }

            Port p1 = e1.getPort(link[0]);


            if (p1.isOutputPort())
                return p1;
        }
        // assert(oo!=null);
        return oo;
    }

    private static ArrayList<Node> parseXMLTree(Node node, String str) {
        al = new ArrayList<>();
        return parseXMLTree1(node, str);
    }

    private static ArrayList<Node> parseXMLTree1(Node node, String str) {
        NodeList ll = node.getChildNodes();
        for (int i = 0; i < ll.getLength(); i++) {
            Node no = ll.item(i);
            if (no.getNodeType() == Node.ELEMENT_NODE) {
                if (no.getNodeName().equalsIgnoreCase(str)) {
                    al.add(no);
                }
                parseXMLTree1(no, str);
            }
        }// for
        return al;
    }


    private static void printAttrib(Node node) {
        if (!node.hasAttributes()) {
            return;
        }
        NamedNodeMap no = node.getAttributes();
        printNodeType(node.getNodeType());

        for (int j = 0; j < no.getLength(); j++) {
            Node map = no.item(j);

            Node no1 = no.item(j);
            printNodeType(no1.getNodeType());

            System.err.println(map.getNodeName());
            System.err.println(map.getNodeValue());

        }
    }

    private static void printNodeType(short type) {
        switch (type) {
            case Node.ELEMENT_NODE:
                System.err.println("Element Node");
                break;
            case Node.ATTRIBUTE_NODE:
                System.err.println("ATTRIBUTE Node");
                break;
            case Node.ENTITY_NODE:
                System.err.println("Entity Node");
                break;
            case Node.TEXT_NODE:
                System.err.println("TEXT Node");
                break;
            case Node.COMMENT_NODE:
                System.err.println("COMMENT Node");
                break;
            case Node.CDATA_SECTION_NODE:
                System.err.println("CDATA SECTION Node");
                break;
            case Node.DOCUMENT_NODE:
                System.err.println("DOCUMENT Node");
                break;
            case Node.DOCUMENT_TYPE_NODE:
                System.err.println("DOCUMENT TYPE Node");
                break;
            case Node.NOTATION_NODE:
                System.err.println("NOTATION Node");
                break;
            case Node.ENTITY_REFERENCE_NODE:
                System.err.println("ENTITY REFERENCE Node");
                break;
            case Node.PROCESSING_INSTRUCTION_NODE:
                System.err.println("PROCESSING Node");
                break;
            default:
                assert (false);
        }
    }

    /**
     * fügt jeder Komponente ihre Eigenschaften hinzu Name,#Eing#nge -Ausgnge
     * usw.
     *
     * @param ar
     * @param ee
     */
    private static void setComponentProperties(ArrayList<Node> ar,
                                               XMLComponent ee) {
        for (Node node : ar) {
            if (!node.hasAttributes()) {
                continue;
            }

            NamedNodeMap no = node.getAttributes();
            Node map = no.item(0);
            if (map.getNodeValue().equalsIgnoreCase("LPM_TYPE")) {
                ee.lpm_type = node.getFirstChild().getTextContent();
            }
            if (map.getNodeValue().equalsIgnoreCase("LPM_CValue")) {
                String num = node.getFirstChild().getTextContent().trim();
                ee.lpm_cvalue = Integer.parseInt(num);
            }

            if (map.getNodeValue().equalsIgnoreCase("LPM_Width")) {
                String num = node.getFirstChild().getTextContent().trim();
                ee.lpm_width = Integer.parseInt(num);
            }
            if (map.getNodeValue().equalsIgnoreCase("LPM_Size")) {
                String num = node.getFirstChild().getTextContent().trim();
                ee.lpm_size = Integer.parseInt(num);
            }
        }// while
    }

    /**
     * erzeugt aus den Entities einen Graph
     *
     * @return Graph
     */

    private static Graph buildDeviceGraph() {
        graph = new Graph();
        Collection<Entity> col = viewRef.values();

        Entity top = viewRef.get(topModule);
        graph.addNode(top.getIdd());
        for (Entity en : col) {
            if (en.equals(top))
                continue;


            Vector<Port> out = en.getAllOutPorts();

            for (Port po : out) {
                String from = po.getEntity().getCompName();

                Entity e1 = viewRef.get(from);

                if (po.getLinkOutput().isEmpty())
                    continue;

                for (Port pp : po.getLinkOutput()) {

                    if (pp.getEntity().getCompName() == topModule) {
                        Entity et = viewRef.get(pp.getPortName());
                        graph.addEdge(e1.getIdd(), et.getIdd());
                    } else {
                        graph.addEdge(e1.getIdd(), pp.getEntity().getIdd());
                    }
                }
            }
        }// for

        Vector<Port> inp = top.getAllInputPorts();
        for (Port pi : inp) {
            if (pi.getLinkOutput().isEmpty())
                break;
            Entity en = viewRef.get(pi.getPortName());
            Port pin = en.getPort(en.getCompName());
            assert (pin != null);
            for (Port po : pi.getLinkOutput()) {
                pin.addPort( po);
                graph.addEdge(en.getIdd(), po.getEntity().getIdd());
            }
        }

        Vector<Port> out = top.getAllOutPorts();
        for (Port po : out) {
            if (po.isBus())
                continue;
            System.out.println(po.getPortName());
            Entity ee = viewRef.get(po.getPortName());
            graph.addNode(ee.getIdd());
        }

        // System.out.println(graph.getEdges());
        return graph;
    }


    private static String topModule = null;

    /**
     * @return Name des top moduls
     */
    public static String getTopModuleName() {
        return topModule;
    }

    /**
     * @return Entity des top moduls
     */
    public static Entity getTopEntity() {
        return viewRef.get(topModule);
    }

    /**
     * @param entName Identifikationsnummer der Entity
     * @return Entity
     */
    public static int getEntityIDD(String entName) {
        Entity ee = getEntity(entName);
        assert (ee != null);
        return ee.getIdd();
    }

    /**
     * @return Komponentenvektor
     */

    public static Hashtable<String, XMLComponent> getComponentList() {
        return vecComponent;
    }

    public static String getCompName(int i) {
        Entity ee = getEntity(i);
        if (ee == null) return null;
        return ee.getCompName();
    }


    /**
     * @param s portName der Entity
     * @return Entity
     */

    public static Entity getEntity(String s) {
        return viewRef.get(s);
    }

    /**
     * @param i idd der Entity
     * @return Entity
     */
    public static Entity getEntity(int i) {
        return entityRef.get(i);
    }

    public static Hashtable<Integer, Entity> getEntityReferenceList() {
        return entityRef;
    }

    /**
     * Entity Hashtable mit Namen
     *
     * @return Hashtable
     */

    public static Hashtable<String, Entity> getEntityList() {
        return viewRef;
    }

    private static ArrayList<Node> al;

    public static Graph getDeviceGraph() {

        if (graph == null)
            return buildDeviceGraph();

        return graph;
    }

    private static Hashtable<String, XMLComponent> vecComponent = new Hashtable<>(
            1000);

    private static Hashtable<String, Entity> viewRef = new Hashtable<>(1000);


    private static Hashtable<Integer, Entity> entityRef = new Hashtable<>(1000);


    private static Document doc = null;

    private static NetDictionary netD = NetDictionary.getInstance();

    /**
     * Zustandsgraph der Schaltung
     */
    private static Graph graph = null;

    /**
     * alle Input Ports starten von diesen Knoten
     */
    private static int superInput;

    /**
     * alle Outputport landen in diesen Knoten
     */
    private static int superOutput;

    private static PartGraph partGraph=null;

    private static List<Edge> backEdges;

    public static List<Edge> getBackEdges(){ return backEdges;}


    public static PartGraph getPartGraph() {return partGraph;}

    public static void main(String[] args) {
        int len = args.length;
        if (len >= 1) {
            topModule = args[0].toLowerCase();
        }
        if (len == 0) {
            System.out.println("missing top module !");
            return;
        }

        try {
            // File stocks = new File("iirq.xml");
            //  File stocks = new File("irqxxx.xml");
            File stocks = new File("uartxxx.xml");
           //   File stocks = new File("uarttest.xml");
            //   File stocks = new File("bcdadd.xml");
            //  File stocks = new File("des3.xml");
            //  File stocks = new File("prototype_xxx.xml");


            DocumentBuilderFactory dbFactory = DocumentBuilderFactory
                    .newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(stocks);
            doc.getDocumentElement().normalize();

            createEntities();

            createEntityReference();

            NodeList nodes = doc.getElementsByTagName("component");
            for (int i = 0; i < nodes.getLength(); i++) {
                Node node = nodes.item(i);
                if (node.getChildNodes().getLength() >= 0) {
                    parseXMLTree(node);
                    if (!spec.isEmpty()) {
                        parseConnection1(spec);
                        spec.clear();
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            assert (false);
        }


        // debugEntities();
        assignEntityReference();

        addRefsToBus();

        /**
         * erstellt aus den Entities und IO-Ports den Zustandsgraphen
         */

        buildDeviceGraph();

        /**
         * fasse alle IO-Ports vom Top Modul zu einen einzigen Knoten zusammen
         * SI - INPUT SO - OUTPUT
         */
        createSuperNodes();

        /**
         * erstelle Invers,n Graph drehe Vorwätskanten um (Rückwärtskante
         */

        //  netD.debugAll();
        Graph gInv = graph.inverseGraph();
        DFS ffh = new DFS();
        backEdges = ffh.dsf(gInv, superOutput);

         /**
         * entferne Rückwärtskanten aus dem Graphen
         */

        gInv.removeEdgeSCC(backEdges);
        PartitionGraph dd=new PartitionGraph(gInv,superOutput,100);
        List<PartGraph> pgList=dd.getPartGraphList();

        for(int ig=0;ig<pgList.size();ig++) {
            String fi = "Graph_" + Integer.toString(ig) + "__"+Utility.getTime()+".svg";
             PartGraph pg=pgList.get(ig);
            Href.addHref(new Href(fi,pg.getNodes()));
        }

        Href.debugAll();
        /*
        List<String> ls=Href.getAllOutports();
        ls.forEach(ss->Href.findInputPorts(ss));
        System.out.println("<----------------------------------------------------->");
        ls.clear();
        ls=Href.getAllInports();
        ls.forEach(ss->Href.findOutputPorts(ss));
        */
        //Href.findPorts("U14_Result");
     //   System.exit(0);
        for(int ig=0;ig<pgList.size();) {
            partGraph=pgList.get(ig);
            PartGraph pg=pgList.get(ig);
            gInv = pg.getPartGraph();
             Map<Integer, Integer> val = LongestPath
                    .computeAllLongestPath1(gInv, pg.getSoId());
           // LongestPath.printLongestPath(val, pg);
            System.out.println("----------------,,,------------------------");
            String fi="Graph_"+Integer.toString(ig++)+"__";

            NetlistWriter svg = new NetlistWriter(fi);
            LongestPath lg = new LongestPath(val);
            NetListBuilder builder = new NetListBuilder(pg,lg,svg);
            svg.endSVG(); //
        }
        System.out.println("\n <  ...finish drawing graph...   >");
    }
}// class
