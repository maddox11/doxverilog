package xml;

import java.util.*;

import xml.geom.Entity2D.Ent2DNode;
import xml.geom.Entity2D.*;
import xml.geom.LineXY;
import xml.geom.PointXY;

public class NetListContainer {

    final private static PointXY pcmp;
    private static Hashtable<String, ArrayList<NetListContainer>> sigCont;

    static {
        sigCont = new Hashtable<>();
        pcmp = new PointXY();
    }


    public static void reset() {
        sigCont.clear();
    }

    private LinkedList<LineXY> signalPath = new LinkedList<>();

    /**
     * enthaelt alle Punkte(Ports) eines Pfades
     * index 0 ist der Ausgangsport (OUT port)
     * index 1..n-1 sind die Eingangsports (INPUT port)
     */

    private ArrayList<PointXY> pointList = new ArrayList<>();
    private boolean isBus = false;
    private String outPort = null;
    private String entity = null;
    private int idd = 0;

    public NetListContainer(String entity, String outPort, int idd) {
        this.entity = entity;
        this.outPort = outPort;
        this.idd = idd;
        assert (entity != null);
        Ent2DNode cmp = E2DCont.getEnt2DNode(entity);
        Port2D p22 = cmp.getE2d().getPort(outPort);
        isBus = p22.isBus();
        if (isBus) {
            System.out.println(entity + " port :" + outPort + " =Bus ");
        }
        addPathToContainer();
    }


    // TODO Auto-generated constructor stub

    public static NetListContainer getOutPath(String entity, String outport) {
        ArrayList<NetListContainer> sig = sigCont.get(entity);
        for (NetListContainer cont : sig) {
            if (cont.outPort.equalsIgnoreCase(outport))
                return cont;
        }
        assert (false);
        return null;
    }


    public static List<LineXY> getAllLinesAtXY(int xy, boolean row) {
        ArrayList<LineXY> allLines = new ArrayList<LineXY>();
        Enumeration<ArrayList<NetListContainer>> allc = NetListContainer.sigCont.elements();
        while (allc.hasMoreElements()) {
            ArrayList<NetListContainer> arr = allc.nextElement();
            for (NetListContainer siggi : arr) {
                if (row)
                    allLines.addAll(siggi.getHLinesAtCol(xy));
                else
                    allLines.addAll(siggi.getVLinesAtRow(xy));
            }//for
        }//while

        if (row)
            Collections.sort(allLines, new LineXY.LineXYHor());
        else
            Collections.sort(allLines, new LineXY.LineXYVer());

        return allLines;
    }


    public List<PointXY> getInputPinsAt(int col) {
        ArrayList<PointXY> pinList = new ArrayList<>();
        for (PointXY pt : pointList) {
            if (pt.getX() == col)
                pinList.add(pt);

        }
        return pinList;
    }


    public void addPointCloud(java.util.List<PointXY> pxy) {
        assert (pxy.size() > 0);
        //     startPoint = pxy.get(0);
        pointList.addAll(pxy);
    }

    private void addPathToContainer() {
        if (sigCont.containsKey(entity)) {
            ArrayList<NetListContainer> sigList = sigCont.get(entity);
            sigList.add(this);
            //  System.out.println("Adding Entity " + entity + " Outport " + outPort);
        } else {
            ArrayList<NetListContainer> sigList = new ArrayList<>();
            sigCont.put(entity, sigList);
            sigList.add(this);
            //  System.out.println("create container & Adding Entity " + entity + " Outport " + outPort);
        }
    }


    private List<LineXY> getHLinesAtCol(int i) {
        ArrayList<LineXY> hLines = new ArrayList<>();

        for (LineXY line : signalPath) {
            if (line.isVerticalLine())
                continue;

            if (line.y1 == i && line.y2 == i)
                hLines.add(line);
        }

        return hLines;
    }

    private List<LineXY> getVLinesAtRow(int i) {
        ArrayList<LineXY> vLines = new ArrayList<>();

        for (LineXY line : signalPath) {
            boolean b = line.isPoint();
            if (line.isHorizontalLine() && !b)
                continue;


            if (line.x1 == i && line.x2 == i)
                vLines.add(line);
        }
        return vLines;
    }

    public void checkSignalPath(List<LineXY> list, Port2D p2d1) {
        int x = p2d1.column;
        int y = p2d1.line;
        for (LineXY line : list) {
            if (line.isVerticalLine())
                if (line.x1 > x)
                    line.setBackEdge(true);
                else {
                    if (line.x2 > x)
                        line.setBackEdge(true);
                }

        }
    }

    public boolean isBus() {
        return isBus;
    }


    public LinkedList<LineXY> getSignalPath() {
        return signalPath;
    }

    public String getOutPort() {
        return outPort;
    }

    public String getEntity() {
        return entity;
    }

    public int getIdd() {
        return idd;
    }

    public ArrayList<PointXY> getPointList() {
        return pointList;
    }

    public static Hashtable<String, ArrayList<NetListContainer>> getSigCont() {
        return sigCont;
    }

    public static ArrayList<NetListContainer> getNetList(String ent) {
        return sigCont.get(ent);
    }

    public static NetListContainer getNetList(String entity, String port) {
        //  System.out.println(entity+"--##-- "+port);
        ArrayList<NetListContainer> arr = sigCont.get(entity);

        for (NetListContainer net : arr) {
            if (net.getOutPort().equalsIgnoreCase(port))
                return net;
        }

        return null;
    }
}//class

